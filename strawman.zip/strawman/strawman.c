/**
 * \file
 *         Low-power receiver-initiated MAC protocol with StrawMAN.
 *         *EXPERIMENTAL*
 * \author
 *         Fredrik Osterlind
 */

#include "contiki.h"
#include "lib/list.h"
#include "lib/memb.h"
#include "lib/random.h"
#include "lib/ringbuf.h"
#include "net/netstack.h"
#include "net/rime.h"
#include "net/mac/mac.h"
#include "net/packetbuf.h"
#include "dev/watchdog.h"
#include "dev/leds.h"
#include "dev/cc2420.h"

#include "strawman.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <io.h>
#include <signal.h>
#include <sys/unistd.h>
#include "msp430.h"
#include "dev/watchdog.h"
#include "net/uip.h"
#include "node-id.h"

#define DEBUG 0
#if DEBUG
#include <stdio.h>
#define PRINTF(...) printf(__VA_ARGS__)
#else
#define PRINTF(...)
#endif

#undef LEDS_ON
#undef LEDS_OFF
#undef LEDS_TOGGLE
#define LEDS_ON(l)
#define LEDS_OFF(l)
#define LEDS_TOGGLE(l)
/*#define LEDS_ON(l) leds_on(l)
#define LEDS_OFF(l) leds_off(l)
#define LEDS_TOGGLE(l) leds_toggle(l)*/

/* Optimization: Store encounters */
#define WITH_ENCOUNTER_OPTIMIZATION   1
/* Optimization: No StrawMAN first try */
#define WITH_INITIAL_DATAPROBES       1 /* 0 => encounters do not work */
/* Optimization: Immediately trigger next voting period */
#define WITH_QUICK_ROUNDS 1
/* Optimization: Data probes on dedicated channel */
#define WITH_MULTICHANNEL 1 /* req. WITH_INITIAL_DATAPROBES */
#define PROBE_CHANNEL 11
/* Optimization: Send signal immediately when CCA true */
#define WITH_ADAPTIVE_REQUEST_PHASE 1
/* TODO Remove acks (optional) */

/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */
#define PROBE_INTERVAL (1*CLOCK_SECOND/1)
//#define PROBE_INTERVAL (16*CLOCK_SECOND/1)
//#ifdef QUEUEBUF_CONF_NUM
//#define MAX_QUEUED_PACKETS QUEUEBUF_CONF_NUM / 2
//#else /* QUEUEBUF_CONF_NUM */
//#define MAX_QUEUED_PACKETS 32 /* 2011-03-23 */
#define MAX_QUEUED_PACKETS (QUEUEBUF_CONF_NUM / 2)
//#endif /* QUEUEBUF_CONF_NUM */
#define MAX_ENCOUNTERS 4
/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */


#define PACKET_LIFETIME PROBE_INTERVAL
//#define UNICAST_TIMEOUT (4 * PACKET_LIFETIME) /* 2011-03-23 */
#define UNICAST_TIMEOUT (32 * PACKET_LIFETIME)

#define ENCOUNTER_LIFETIME (128 * CLOCK_SECOND)

/* If CLOCK_SECOND is less than 4, we may end up with an PROBE_INTERVAL that
   is 0 which will make compilation fail due to a modulo operation in
   the code. To ensure that PROBE_INTERVAL is greater than zero, we use the
   construct below. */
#if PROBE_INTERVAL == 0
#undef PROBE_INTERVAL
#define PROBE_INTERVAL 1
#endif

/* Samples to bytes conversion */
#define VOTE_INTERVAL 7
#define VOTE_MAX_LENGTH 119 /* 112+7 */
#define THRESHOLD_BYTES 3 /* TODO Error model? */

#if WITH_ADAPTIVE_REQUEST_PHASE
// XXX Should probably be set back to 22, since rssi is always read nowadays..
#define SAMPLES_MIN 30 /* XXX Should be increased by 8 from 22 according to calib! */
//#define SAMPLES_MIN 70 /* 2011-03.17. Contiki timers changed. */
#define SAMPLES_INTERVAL 35 /* samples per vote interval */
#else /* WITH_ADAPTIVE_REQUEST_PHASE */
#error Need calibration.
#endif /* WITH_ADAPTIVE_REQUEST_PHASE */

#define REQ_COMPETE_NEXT_BC 0
#if REQ_COMPETE_NEXT_BC
static int compete_next = 0;
static uint16_t req_start_time;
static uint16_t req_finished_time;
static uint16_t req_probes_seen;
#endif

/* Progress debug info */
int progress_1 = 0; /* sender: rx interrupt */
int progress_2 = 0; /* sender: competing (sent vote) */
int progress_3 = 0; /* sender: winner! */
int progress_4 = 0; /* sender: sent data packet */
int progress_5 = 0; /* receiver: triggered vote round (sent probe) */
int progress_6 = 0; /* receiver: estimated bad vote size */
int progress_7 = 0; /* receiver: sent signal to winner */
int progress_8 = 0; /* receiver: received data packet */
int progress_9 = 0; /* failure: wait for sfd=false */
int progress_10 = 0; /* failure: wait for sfd=true */
int progress_11 = 0; /* failure: wait for cca traffic */
int progress_12 = 0; /* UNKNOWN */
int progress_14 = 0; /* longest probe_timer loop duration */
int progress_15 = 0; /* redundant wakeups */
int progress_16 = 0; /* wakeups (total) */

static int testmode_print_requests = 0;
static int testmode_always_request = 0;
static int testmode_print_request_rssi = 0;
static int testmode_always_data = 0;
static int testmode_discard_data = 0;
static int testmode_dont_compete = 0;
static int testmode_no_probes = 0;
static int testmode_no_cts = 0;
static int testmode_limit_bc_tx = 0;
static int testmode_no_logs = 0;
static int testmode_radio_on = 0;
static int testmode_instant_broadcasts = 0;
static int testmode_rimac = 0;
#define TESTMODE_LIMIT_BC_TX_NUM 5

int strawman_got_synch = 0;

static uint16_t buf_voteprobes_counter=1;
struct ringbuf buf_competitions;
static uint8_t buf_competitions_data[2];
struct ringbuf buf_signals;
static uint8_t buf_signals_data[2];
struct ringbuf buf_wins;
static uint8_t buf_wins_data[2];
struct ringbuf buf_data;
static uint8_t buf_data_data[2];

#if REQ_COMPETE_NEXT_BC
struct ringbuf buf_latency;
static uint8_t buf_data_latency[256];
#endif

/*---------------------------------------------------------------------------*/

static uint8_t strawman_is_on;
static struct pt dutycycle_pt;
static struct ctimer timer;
static struct ctimer probe_timer; /* trigger votes */
static struct ctimer competition_timer; /* competition timeout */

static clock_time_t off_time = PROBE_INTERVAL;

struct queue_list_item {
  struct queue_list_item *next;
  struct queuebuf *packet;
  struct ctimer removal_timer;
  rimeaddr_t dest;
  int bc;
  rimeaddr_t bc_acked_by;
  int WAS_POSTPONED;
  mac_callback_t mac_callback;
  void *mac_callback_ptr;
  int numtx;
  int acked;
  uint16_t p_seq;
  int removeme;
};

#define DIFF(cmp1, cmp2) (RTIMER_CLOCK_LT(cmp1,cmp2)?cmp2-cmp1:cmp1-cmp2)

/* MAC protocol header: 8 bytes (fixed) */
struct strawman_hdr {
  uint8_t type; /* packet type */
  uint8_t seq; /* data sequence number, also used to ack data */ /* XXX Fairness? */
  rimeaddr_t sender; /* packet sender/source */
  rimeaddr_t ack; /* optional: data ack address, used in TYPE_VOTE_PROBE */
  rimeaddr_t receiver; /* packet receiver/destination (TYPE_DATA) OR size estimation*/
};

/* Packet types (strawman_hdr) */
#define TYPE_NULL          0
#define TYPE_DATA_PROBE    1 /* Free-for-all data probe */
#define TYPE_VOTE_PROBE    2 /* Vote probe sent by receive-ready nodes.
                              * Optionally includes ack for previously received data. */
#define TYPE_VOTE          3 /* Vote sent by competing send-ready nodes. Will collide. */
#define TYPE_SIGNAL        4 /* Signal packet, sent to declare vote winner */
#define TYPE_DATA          5 /* Data packet. Includes seq, sender, receiver. */

extern int cc2420_cca_fast(void);
extern int cc2420_rssi_fast(void);
extern int cc2420_flushrx(int reason);
extern void cc2420_set_peek_handler(int (*handler)(uint8_t* hdr, uint16_t delayed), int size);
//extern int clock_repair(void);
static void turn_radio_on_callback(void *packet);
static void restart_dutycycle(clock_time_t initial_wait);

extern void debug_str(char* str);
#define COOJA_DEBUG(str) debug_str(str)
/*#define COOJA_DEBUG(str)*/
#define ERROR(str) COOJA_DEBUG(str)

static uint8_t debug_preloaded_type = -1; /* Debug: currently preloaded radio packet */
#define ASSERT_PRELOADED(type, msg) if (type != debug_preloaded_type) { ERROR(msg); }

/* Data sequences and acknowledgements */

static rimeaddr_t last_data_source; /* Last received data packet source */
static uint8_t last_data_seq; /* Last received data packet sequence number */

static rimeaddr_t competition_neighbor;

static rimeaddr_t alert_guy;
static int alert_count;

static int is_competing = 0;
static clock_time_t is_competing_time = 0;
static int is_triggering = 0;
static int stop_sending_probes = 0;

static int my_data_channel;

LIST(callback_packets_list);
LIST(pending_packets_list);
LIST(queued_packets_list);
LIST(incoming_packets_list);
MEMB(queued_packets_memb, struct queue_list_item, MAX_QUEUED_PACKETS);

struct encounter {
  struct encounter *next;
  rimeaddr_t neighbor;
  clock_time_t time;
  struct ctimer remove_timer;
  struct ctimer turn_on_radio_timer;
  struct ctimer turn_off_radio_timer;
  int turn_off_radio_timer_counter;
  int ignored;
  int ALERT_HIM;


#define WITH_BAN 0
#if WITH_BAN
  /* Forever banned (asymmetric link).
   * Happens when I compete and win, but never receive acks...*/
  int banned;
  int banned_comp; /* competitions without wins.. */
  int banned_wins; /* wins without acks.. */
#endif /* WITH_BAN */
};

LIST(encounter_list);
MEMB(encounter_memb, struct encounter, MAX_ENCOUNTERS);

/*---------------------------------------------------------------------------*/
PROCESS(competition_timout_process, "competition timeout");
/*---------------------------------------------------------------------------*/
static int
log_competition(struct ringbuf *rb, rimeaddr_t *seq, rimeaddr_t *addr)
{
  if (testmode_no_logs) {
    return 0;
  }

  if (ringbuf_elements(rb) > 250) {
    if (rb == &buf_competitions) {
      COOJA_DEBUG("XXX competitions ring buffer full, ignoring data");
    } else if (rb == &buf_signals) {
      COOJA_DEBUG("XXX signals ring buffer full, ignoring data");
    } else if (rb == &buf_wins) {
      COOJA_DEBUG("XXX wins ring buffer full, ignoring data");
    } else if (rb == &buf_data) {
      COOJA_DEBUG("XXX data ring buffer full, ignoring data");
#if REQ_COMPETE_NEXT_BC
    } else if (rb == &buf_latency) {
      COOJA_DEBUG("XXX latency ring buffer full, ignoring data");
#endif
    } else {
      COOJA_DEBUG("XXX unknown ring buffer full, ignoring data");
    }
    return 1;
  }

  ringbuf_put(rb, seq->u8[0]);
  ringbuf_put(rb, seq->u8[1]);
  ringbuf_put(rb, addr->u8[0]);
  ringbuf_put(rb, addr->u8[1]);
  return 0;
}
/*---------------------------------------------------------------------------*/
static struct encounter*
get_encounter(rimeaddr_t *neighbor)
{
  struct encounter *e;
  if (neighbor == NULL) {
    return NULL;
  }
  for(e = list_head(encounter_list); e != NULL; e = e->next) {
    if(rimeaddr_cmp(neighbor, &e->neighbor)) {
      return e;
    }
  }
  return NULL;
}
/*---------------------------------------------------------------------------*/
static int
is_competing_now(void)
{
  clock_time_t diff;

  if (!is_competing) {
    return 0;
  }
  diff = clock_time() - is_competing_time;
  if (diff < 3) {
    return 1;
  } else {
    is_competing = 0;
    return 0;
  }
}
/*---------------------------------------------------------------------------*/
static int
have_queued_broadcast(void)
{
  struct queue_list_item *i;
  for(i = list_head(queued_packets_list); i != NULL; i = i->next) {
    if(i->bc) {
      return 1;
    }
  }
  return 0;
}
/*---------------------------------------------------------------------------*/
static int
have_queued_unicast(void)
{
  struct queue_list_item *i;
  for(i = list_head(queued_packets_list); i != NULL; i = i->next) {
    if(!i->bc) {
      return 1;
    }
  }
  return 0;
}
/*---------------------------------------------------------------------------*/
static int
led_queued_broadcast(void)
{
/*  if (have_queued_broadcast()) {
    leds_on(LEDS_RED);
  } else {
    leds_off(LEDS_RED);
  }
  if (have_queued_unicast()) {
    leds_on(LEDS_GREEN);
  } else {
    leds_off(LEDS_GREEN);
  }*/
  return 0;
}
/*---------------------------------------------------------------------------*/
static int
num_packets_to_send(void)
{
  return list_length(queued_packets_list);
}
/*---------------------------------------------------------------------------*/
#define TURN_RADIO_ON_REASON_BC 1
#define TURN_RADIO_ON_REASON_MORE_PACKETS 2
#define TURN_RADIO_ON_REASON_TRIGGER_VOTE 3
#define TURN_RADIO_ON_REASON_NO_ENCOUNTER 4
#define TURN_RADIO_ON_REASON_CALLBACK 5
static void
turn_radio_on(int reason)
{
  if (reason == TURN_RADIO_ON_REASON_BC) {
    COOJA_DEBUG("TURN_RADIO_ON_REASON_BC");
  } else if (reason == TURN_RADIO_ON_REASON_MORE_PACKETS) {
    //COOJA_DEBUG("TURN_RADIO_ON_REASON_MORE_PACKETS");
  } else if (reason == TURN_RADIO_ON_REASON_TRIGGER_VOTE) {
    //COOJA_DEBUG("TURN_RADIO_ON_REASON_TRIGGER_VOTE");
  } else if (reason == TURN_RADIO_ON_REASON_NO_ENCOUNTER) {
    COOJA_DEBUG("TURN_RADIO_ON_REASON_NO_ENCOUNTER");
  } else if (reason == TURN_RADIO_ON_REASON_CALLBACK) {
    COOJA_DEBUG("TURN_RADIO_ON_REASON_CALLBACK");
  } else {
    COOJA_DEBUG("TURN_RADIO_ON_REASON_UNKNOWN");
  }

  NETSTACK_RADIO.on();
  /*LEDS_ON(LEDS_YELLOW);*/
}
/*---------------------------------------------------------------------------*/
static void
print_queued_destinations()
{
  struct queue_list_item *i;
  for(i = list_head(queued_packets_list); i != NULL; i = i->next) {
    struct strawman_hdr *qhdr;
    qhdr = queuebuf_dataptr(i->packet);

    if(qhdr->receiver.u8[0] == 0) {
      COOJA_DEBUG("-> 0");
    } else if(qhdr->receiver.u8[0] == 1) {
      COOJA_DEBUG("-> 1");
    } else if(qhdr->receiver.u8[0] == 2) {
      COOJA_DEBUG("-> 2");
    } else if(qhdr->receiver.u8[0] == 3) {
      COOJA_DEBUG("-> 3");
    } else if(qhdr->receiver.u8[0] == 4) {
      COOJA_DEBUG("-> 4");
    } else if(qhdr->receiver.u8[0] == 5) {
      COOJA_DEBUG("-> 5");
    } else if(qhdr->receiver.u8[0] == 6) {
      COOJA_DEBUG("-> 6");
    } else if(qhdr->receiver.u8[0] == 7) {
      COOJA_DEBUG("-> 7");
    } else if(qhdr->receiver.u8[0] == 8) {
      COOJA_DEBUG("-> 8");
    } else if(qhdr->receiver.u8[0] == 9) {
      COOJA_DEBUG("-> 9");
    } else if(qhdr->receiver.u8[0] == 10) {
      COOJA_DEBUG("-> 10");
    } else if(qhdr->receiver.u8[0] == 11) {
      COOJA_DEBUG("-> 11");
    } else if(qhdr->receiver.u8[0] == 12) {
      COOJA_DEBUG("-> 12");
    } else if(qhdr->receiver.u8[0] == 13) {
      COOJA_DEBUG("-> 13");
    } else if(qhdr->receiver.u8[0] == 14) {
      COOJA_DEBUG("-> 14");
    } else if(qhdr->receiver.u8[0] == 15) {
      COOJA_DEBUG("-> 15");
    } else if(qhdr->receiver.u8[0] == 16) {
      COOJA_DEBUG("-> 16");
    } else {
      COOJA_DEBUG("-> ??");
    }
  }

}
/*---------------------------------------------------------------------------*/
static void
print_callback_destinations()
{
  struct queue_list_item *i;
  for(i = list_head(callback_packets_list); i != NULL; i = i->next) {
    struct strawman_hdr *qhdr;
    qhdr = queuebuf_dataptr(i->packet);

    if(i->dest.u8[0] == 0) {
      COOJA_DEBUG("-> 0");
    } else if(i->dest.u8[0] == 1) {
      COOJA_DEBUG("-> 1");
    } else if(i->dest.u8[0] == 2) {
      COOJA_DEBUG("-> 2");
    } else if(i->dest.u8[0] == 3) {
      COOJA_DEBUG("-> 3");
    } else if(i->dest.u8[0] == 4) {
      COOJA_DEBUG("-> 4");
    } else if(i->dest.u8[0] == 5) {
      COOJA_DEBUG("-> 5");
    } else if(i->dest.u8[0] == 6) {
      COOJA_DEBUG("-> 6");
    } else if(i->dest.u8[0] == 7) {
      COOJA_DEBUG("-> 7");
    } else if(i->dest.u8[0] == 8) {
      COOJA_DEBUG("-> 8");
    } else if(i->dest.u8[0] == 9) {
      COOJA_DEBUG("-> 9");
    } else if(i->dest.u8[0] == 10) {
      COOJA_DEBUG("-> 10");
    } else if(i->dest.u8[0] == 11) {
      COOJA_DEBUG("-> 11");
    } else if(i->dest.u8[0] == 12) {
      COOJA_DEBUG("-> 12");
    } else if(i->dest.u8[0] == 13) {
      COOJA_DEBUG("-> 13");
    } else if(i->dest.u8[0] == 14) {
      COOJA_DEBUG("-> 14");
    } else if(i->dest.u8[0] == 15) {
      COOJA_DEBUG("-> 15");
    } else if(i->dest.u8[0] == 16) {
      COOJA_DEBUG("-> 16");
    } else {
      COOJA_DEBUG("-> ??");
    }
  }

}
/*---------------------------------------------------------------------------*/
static void
print_pending_destinations()
{
  struct queue_list_item *i;
  for(i = list_head(pending_packets_list); i != NULL; i = i->next) {
    struct strawman_hdr *qhdr;
    qhdr = queuebuf_dataptr(i->packet);

    if(qhdr->receiver.u8[0] == 0) {
      COOJA_DEBUG("-> 0");
    } else if(qhdr->receiver.u8[0] == 1) {
      COOJA_DEBUG("-> 1");
    } else if(qhdr->receiver.u8[0] == 2) {
      COOJA_DEBUG("-> 2");
    } else if(qhdr->receiver.u8[0] == 3) {
      COOJA_DEBUG("-> 3");
    } else if(qhdr->receiver.u8[0] == 4) {
      COOJA_DEBUG("-> 4");
    } else if(qhdr->receiver.u8[0] == 5) {
      COOJA_DEBUG("-> 5");
    } else if(qhdr->receiver.u8[0] == 6) {
      COOJA_DEBUG("-> 6");
    } else if(qhdr->receiver.u8[0] == 7) {
      COOJA_DEBUG("-> 7");
    } else if(qhdr->receiver.u8[0] == 8) {
      COOJA_DEBUG("-> 8");
    } else if(qhdr->receiver.u8[0] == 9) {
      COOJA_DEBUG("-> 9");
    } else if(qhdr->receiver.u8[0] == 10) {
      COOJA_DEBUG("-> 10");
    } else if(qhdr->receiver.u8[0] == 11) {
      COOJA_DEBUG("-> 11");
    } else if(qhdr->receiver.u8[0] == 12) {
      COOJA_DEBUG("-> 12");
    } else if(qhdr->receiver.u8[0] == 13) {
      COOJA_DEBUG("-> 13");
    } else if(qhdr->receiver.u8[0] == 14) {
      COOJA_DEBUG("-> 14");
    } else if(qhdr->receiver.u8[0] == 15) {
      COOJA_DEBUG("-> 15");
    } else if(qhdr->receiver.u8[0] == 16) {
      COOJA_DEBUG("-> 16");
    } else {
      COOJA_DEBUG("-> ??");
    }
  }

}
/*---------------------------------------------------------------------------*/
static void
print_numpackets()
{
  int n = list_length(queued_packets_list);
  int n2 = list_length(pending_packets_list);
  int n3 = list_length(callback_packets_list);

  if (n2 == 0) {
    COOJA_DEBUG("PENDING 0");
  } else if (n2 == 1) {
    COOJA_DEBUG("PENDING 1");
  } else if (n2 == 2) {
    COOJA_DEBUG("PENDING 2");
  } else if (n2 == 3) {
    COOJA_DEBUG("PENDING 3");
  } else if (n2 == 4) {
    COOJA_DEBUG("PENDING 4");
  } else if (n2 == 5) {
    COOJA_DEBUG("PENDING 5");
  } else {
    COOJA_DEBUG("PENDING >5");
  }
  print_pending_destinations();

  if (n == 0) {
    COOJA_DEBUG("QUEUE 0");
  } else if (n == 1) {
    COOJA_DEBUG("QUEUE 1");
  } else if (n == 2) {
    COOJA_DEBUG("QUEUE 2");
  } else if (n == 3) {
    COOJA_DEBUG("QUEUE 3");
  } else if (n == 4) {
    COOJA_DEBUG("QUEUE 4");
  } else if (n == 5) {
    COOJA_DEBUG("QUEUE 5");
  } else {
    COOJA_DEBUG("QUEUE >5");
  }
  print_queued_destinations();

  if (n3 == 0) {
    COOJA_DEBUG("CALLBACK 0");
  } else if (n3 == 1) {
    COOJA_DEBUG("CALLBACK 1");
  } else if (n3 == 2) {
    COOJA_DEBUG("CALLBACK 2");
  } else if (n3 == 3) {
    COOJA_DEBUG("CALLBACK 3");
  } else if (n3 == 4) {
    COOJA_DEBUG("CALLBACK 4");
  } else if (n3 == 5) {
    COOJA_DEBUG("CALLBACK 5");
  } else {
    COOJA_DEBUG("CALLBACK >5");
  }
  print_callback_destinations();
}
/*---------------------------------------------------------------------------*/
static void
turn_radio_off(void)
{
  if(num_packets_to_send() > 0) {
    return;
  }
  if(strawman_is_on) {
    cc2420_set_channel(PROBE_CHANNEL);
    if (testmode_radio_on) {
      COOJA_DEBUG("testmode_radio_on");
      return;
    }
    if (testmode_always_request || testmode_print_request_rssi) {
      COOJA_DEBUG("TURN_RADIO_OFF REJECT TEST");
      return;
    }
    NETSTACK_RADIO.off();
    return;
  }
  /*LEDS_OFF(LEDS_YELLOW);*/
}
/*---------------------------------------------------------------------------*/
static void
remove_queued_packet(void *s)
{
  struct queue_list_item *i = NULL;
  struct queue_list_item *i2 = NULL;
  uint16_t p_seq = (uint16_t) s;
  if (testmode_always_request) {
    return;
  }

  /* queued */
  for(i = list_head(queued_packets_list); i != NULL; i = i->next) {
    if (i->p_seq == p_seq) {
      COOJA_DEBUG("found in queued, removing");
      /*if (!ctimer_expired(&competition_timer)) {
        COOJA_DEBUG("flagging for removal");
        i->removeme = 1;
        return;
      }*/
      list_remove(queued_packets_list, i);
      i2 = i;
      break;
    }
  }

  /* pending */
  for(i = list_head(pending_packets_list); i != NULL; i = i->next) {
    if (i->p_seq == p_seq) {
      COOJA_DEBUG("found in pending, removing");
      list_remove(pending_packets_list, i);
      i2 = i;
      break;
    }
  }

  if (i2 == NULL) {
    COOJA_DEBUG("XXX remove: not found anywhere, aborting!");
    return;
  }

  /* callback */
  ctimer_stop(&i2->removal_timer);
  queuebuf_free(i2->packet);
  i2->packet = NULL;
  list_add(callback_packets_list, i2);
  led_queued_broadcast();
  if(num_packets_to_send() == 0) {
#if REQ_COMPETE_NEXT_BC
    leds_off(LEDS_ALL);
    if (compete_next == 2) {
      req_finished_time = RTIMER_NOW()-req_start_time;
      log_competition(&buf_latency, (rimeaddr_t*)&req_probes_seen, &req_finished_time);
      req_start_time = -1;
      req_finished_time = -1;
      req_probes_seen = 0;
      compete_next = 0;
      COOJA_DEBUG("YYY compete_next = 0");
      COOJA_DEBUG("XXX reseeding random");
      random_init(RTIMER_NOW()+node_id);
    } else {
      req_start_time = -1;
      req_finished_time = -1;
      req_probes_seen = 0;
    }
#endif
    is_competing = 0;
  }
  turn_radio_off();
}
/*---------------------------------------------------------------------------*/
static void
set_ack_fields(struct strawman_hdr* hdr)
{
  struct encounter *e;

  /* Acknowledge last received data packet */
  rimeaddr_copy(&hdr->ack, &last_data_source);
  if (rimeaddr_cmp(&last_data_source, &rimeaddr_null)) {
    return;
  }

  hdr->seq = last_data_seq;
  e = get_encounter(&last_data_source);

#if 0
  if (rimeaddr_cmp(&last_data_source, &alert_guy) && alert_count > 5) {
    COOJA_DEBUG("XXX ALERT HIM! (no encounter)");
    hdr->seq += 128;
    alert_count = 0; /* reset */
  } else if (e != NULL && e->ALERT_HIM > 5 /*XXX*/) {
    COOJA_DEBUG("XXX ALERT HIM!");
    hdr->seq += 128;
    e->ALERT_HIM = 0; /* reset */
  }
#endif
}
/*---------------------------------------------------------------------------*/
static void
prepare_next_ack(struct strawman_hdr* hdr)
{
  struct encounter *e;

  /* Save acknowledgement for next transmission */
  rimeaddr_copy(&last_data_source, &hdr->sender);
  last_data_seq = hdr->seq & 0x7f;
  e = get_encounter(&last_data_source);
  if (e != NULL) {
    e->ALERT_HIM++;
    if (rimeaddr_cmp(&alert_guy, &hdr->sender)) {
      alert_count = 0;
    }
  } else {
    /* No encounter, store sender in static field */
    if (!rimeaddr_cmp(&alert_guy, &hdr->sender)) {
      rimeaddr_copy(&alert_guy, &hdr->sender);
      alert_count = 0;
    } else {
      alert_count++;
    }
  }
  COOJA_DEBUG("updated data ack data");
}
/*---------------------------------------------------------------------------*/
static int
handle_ack(struct strawman_hdr* hdr)
{
  struct queue_list_item *i;
  int SPECIAL_FIELD = 0;

  if (testmode_always_request) {
    return 0;
  }

  if (hdr->seq & (~0x7f)) {
    SPECIAL_FIELD = 1;
    hdr->seq &= 0x7f;
  }

  /* Handle data packet acknowledgements:
   * Match ack+seq against queued outgoing packets */
  if (!rimeaddr_cmp(&hdr->ack, &rimeaddr_node_addr)) {
    return 0;
  }

  COOJA_DEBUG("ack is for us, checking queued packets");
  for(i = list_head(queued_packets_list); i != NULL; i = i->next) {
    struct strawman_hdr *qhdr;
    qhdr = queuebuf_dataptr(i->packet);

    if (qhdr->seq == hdr->seq) {

#if WITH_BAN
      // XXX FROS DECREASE BANNED_WINS
      {
        struct encounter *e;
        e = get_encounter(&hdr->sender);
        if (e != NULL && e->banned_wins > 0) {
          COOJA_DEBUG("XXX FROS dec banned wins");
          e->banned_wins = 0;
        }
      }
#endif /* WITH_BAN */

      if(i->bc) {
        COOJA_DEBUG("broadcast packet acked, remembering receiver");
        rimeaddr_copy(&i->bc_acked_by, &hdr->sender);
        return 1;
      } else if(rimeaddr_cmp(&qhdr->receiver, &hdr->sender)) {
        COOJA_DEBUG("data packet acked, removing from queue");
        i->acked = 1;
        remove_queued_packet((void*)i->p_seq);

#if 0
        if (SPECIAL_FIELD) {
          COOJA_DEBUG("SPECIAL FIELD, LETS RESTART DUTY CYCLE XXX");
          restart_dutycycle(random_rand() % PROBE_INTERVAL);
        }
#endif

        return 1;
      }
    }
  }

  return 0;
}
/*---------------------------------------------------------------------------*/
static void
preload_dataprobe(void)
{
  struct strawman_hdr *hdr;

  /* Create packet data */
  packetbuf_clear();
  hdr = packetbuf_dataptr();
  hdr->type = TYPE_DATA_PROBE;

  rimeaddr_copy(&hdr->sender, &rimeaddr_node_addr);
  rimeaddr_copy(&hdr->receiver, &rimeaddr_null);

  my_data_channel = PROBE_CHANNEL;
  while (my_data_channel == PROBE_CHANNEL) {
    my_data_channel = 11+((random_rand()/2)%16);
  }
  rimeaddr_copy(&hdr->receiver, (rimeaddr_t*)&my_data_channel);

  /* Acknowledge last received data packet */
  set_ack_fields(hdr);

  packetbuf_set_datalen(sizeof(struct strawman_hdr));

  /* Preload packet */
  NETSTACK_RADIO.prepare(packetbuf_hdrptr(), packetbuf_totlen());
  debug_preloaded_type = TYPE_DATA_PROBE;
  /*COOJA_DEBUG("preloaded data probe packet");*/
}
/*---------------------------------------------------------------------------*/
static void
preload_voteprobe(void)
{
  struct strawman_hdr *hdr;

  /* Create packet data */
  packetbuf_clear();
  hdr = packetbuf_dataptr();
  hdr->type = TYPE_VOTE_PROBE;

  rimeaddr_copy(&hdr->sender, &rimeaddr_node_addr);
  rimeaddr_copy(&hdr->receiver, &rimeaddr_null);

  /* XXX Experimental: create "unique" probe seq number */
  {
    buf_voteprobes_counter++;
    rimeaddr_copy(&hdr->receiver, (rimeaddr_t*)&buf_voteprobes_counter);
  }

  /* Acknowledge last received data packet */
  set_ack_fields(hdr);

  packetbuf_set_datalen(sizeof(struct strawman_hdr));

  /* Preload packet */
  NETSTACK_RADIO.prepare(packetbuf_hdrptr(), packetbuf_totlen());
  debug_preloaded_type = TYPE_VOTE_PROBE;
  /*COOJA_DEBUG("preloaded vote probe packet");*/
}
/*---------------------------------------------------------------------------*/
static int get_random_length(void) {
  int len;
  int r;
#define UNIFORM 0
#if UNIFORM
  len = ((random_rand()/2)%VOTE_MAX_LENGTH);
  len *= VOTE_INTERVAL;
  len %= VOTE_MAX_LENGTH;
#else /* UNIFORM */
  /* GEOMETRIC DISTRIBUTION (p=0.798):
   * This appears to be the optimal values for 2 contenders! */
  r = (random_rand()/3)%1024;
  if (r <= 209) {
    len = 0;
  } else if (r <= 377) {
    len = 7;
  } else if (r <= 511) {
    len = 14;
  } else if (r <= 618) {
    len = 21;
  } else if (r <= 704) {
    len = 28;
  } else if (r <= 772) {
    len = 35;
  } else if (r <= 827) {
    len = 42;
  } else if (r <= 871) {
    len = 49;
  } else if (r <= 906) {
    len = 56;
  } else if (r <= 935) {
    len = 63;
  } else if (r <= 957) {
    len = 70;
  } else if (r <= 975) {
    len = 77;
  } else if (r <= 989) {
    len = 84;
  } else if (r <= 1001) {
    len = 91;
  } else if (r <= 1010) {
    len = 98;
  } else if (r <= 1018) {
    len = 105;
  } else if (r <= 1024 /*duh!*/) {
    len = 112;
  } else {
    len = -1;
  }
#endif /* UNIFORM */

  return len;
}
/*---------------------------------------------------------------------------*/
static int last_vote_len = -1;
static uint8_t tmp_buffer[128];
static void
preload_vote(void)
{
  /* Function is executed from interrupt; it must not acccess packetbuf! */
  struct strawman_hdr *hdr = (struct strawman_hdr*)tmp_buffer;
  if (debug_preloaded_type == TYPE_VOTE) {
    return;
  }

  hdr->type = TYPE_VOTE;
  rimeaddr_copy(&hdr->sender, &rimeaddr_node_addr);
  rimeaddr_copy(&hdr->receiver, &rimeaddr_null);

  last_vote_len = get_random_length();

  /* Preload packet */
  NETSTACK_RADIO.prepare(tmp_buffer, sizeof(struct strawman_hdr) + last_vote_len);
  debug_preloaded_type = TYPE_VOTE;
  /*COOJA_DEBUG("preloaded vote packet");*/
}
/*---------------------------------------------------------------------------*/
static void
preload_signal(int size)
{
  struct strawman_hdr *hdr;

  /* Create packet data */
  packetbuf_clear();
  hdr = packetbuf_dataptr();
  hdr->type = TYPE_SIGNAL;

  rimeaddr_copy(&hdr->sender, &rimeaddr_node_addr);
  rimeaddr_copy(&hdr->receiver, (rimeaddr_t*) &size);

  /* XXX Experimental: "unique" probe seq number */
  {
    rimeaddr_copy(&hdr->ack, (rimeaddr_t*)&buf_voteprobes_counter);
  }

  packetbuf_set_datalen(sizeof(struct strawman_hdr));

  /* Preload packet */
  NETSTACK_RADIO.prepare(packetbuf_hdrptr(), packetbuf_totlen());
  debug_preloaded_type = TYPE_SIGNAL;
  /*COOJA_DEBUG("preloaded signal packet");*/
}
/*---------------------------------------------------------------------------*/
static void
remove_encounter(void *encounter)
{
  struct encounter *e = encounter;

  ctimer_stop(&e->remove_timer);
  ctimer_stop(&e->turn_on_radio_timer);
  ctimer_stop(&e->turn_off_radio_timer);
  list_remove(encounter_list, e);
  memb_free(&encounter_memb, e);
}
/*---------------------------------------------------------------------------*/
static void
competition_timeout(void *n)
{
  struct encounter *e = NULL;
  clock_time_t wait;
  int more_packets;
  struct queue_list_item *i;

  if (num_packets_to_send() == 0) {
    return;
  }
  if (!ctimer_expired(&competition_timer)) {
    COOJA_DEBUG("competition timeout, false alarm");
    return;
  }
  if (have_queued_broadcast()) {
    cc2420_set_channel(PROBE_CHANNEL);
    return;
  }

  COOJA_DEBUG("competition timeout!");

  /* postpone unicast messages, that may otherwise keep radio awake */
#if 1
  /* encounter  */
  for(e = list_head(encounter_list); e != NULL; e = e->next) {
    if(rimeaddr_cmp(&competition_neighbor, &e->neighbor)) {
      clock_time_t now;

      now = clock_time();
      wait = ((clock_time_t)(e->time - now)) % (PROBE_INTERVAL);
      break;
    }
  }
  if (e != NULL) {
    struct queue_list_item *p = NULL;
    print_numpackets();
    COOJA_DEBUG("competition timeout: postponing");
    more_packets = 1;
    while (more_packets) {
      more_packets = 0;
      for(i = list_head(queued_packets_list); i != NULL; i = list_item_next(i)) {
        if(rimeaddr_cmp(&i->dest, &e->neighbor)) {
          p = i;
          list_remove(queued_packets_list, i);
          list_add(pending_packets_list, i);
          COOJA_DEBUG("competition timeout: queue -> pending");
          more_packets = 1;
          break;
        }
      }
    }
    if (p != NULL) {
      ctimer_set(&e->turn_on_radio_timer, wait, turn_radio_on_callback, p);
    }
  }
#endif

  print_numpackets();
  cc2420_set_channel(PROBE_CHANNEL);
  turn_radio_off();
}
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(competition_timout_process, ev, data)
{
  PROCESS_BEGIN();
  while (1) {
    PROCESS_YIELD_UNTIL(ev == PROCESS_EVENT_POLL);
    COOJA_DEBUG("competition_timeout_process");
    ctimer_stop(&competition_timer);
    ctimer_set(&competition_timer, 4, competition_timeout, NULL);
  }
  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
int
strawman_has_encounter(rimeaddr_t *neighbor)
{
  struct encounter *e;
  for(e = list_head(encounter_list); e != NULL; e = e->next) {
    if(rimeaddr_cmp(neighbor, &e->neighbor)) {
      return 1;
    }
  }
  return 0;
}
/*---------------------------------------------------------------------------*/
static void
register_encounter(rimeaddr_t *neighbor, clock_time_t time)
{
  struct encounter *e;

  /* If we have an entry for this neighbor already, we renew it. */
  for(e = list_head(encounter_list); e != NULL; e = e->next) {
    if(rimeaddr_cmp(neighbor, &e->neighbor)) {
      e->time = time;
      e->turn_off_radio_timer_counter = 0;
      ctimer_set(&e->remove_timer, ENCOUNTER_LIFETIME, remove_encounter, e);

#if WITH_BAN
      // XXX FROS CHECK BANNED_COMP
      if (e->banned == 0) {
        if (e->banned_comp > 20) {
          COOJA_DEBUG("XXXX banning forever: comp without wins > 20");
          e->banned = 1;
          printf("banning %d.%d (comp)\n", e->neighbor.u8[0], e->neighbor.u8[1]);
        }
        // XXX FROS CHECK BANNED_COMP
        if (e->banned_wins > 5) {
          COOJA_DEBUG("XXXX banning forever: wins without acks > 5");
          e->banned = 1;
          printf("banning %d.%d (wins)\n", e->neighbor.u8[0], e->neighbor.u8[1]);
        }
      }
#endif /* WITH_BAN */

      break;
    }
  }
  /* No matching encounter was found, so we allocate a new one. */
  if(e == NULL) {
    e = memb_alloc(&encounter_memb);
    if(e == NULL) {
      /* We could not allocate memory for this encounter, so we just drop it. */
      return;
    }
    rimeaddr_copy(&e->neighbor, neighbor);
    e->time = time;
    e->turn_off_radio_timer_counter = 0;
    e->ignored = 0;
#if WITH_BAN
    e->banned = 0;
    e->banned_comp = 0;
    e->banned_wins = 0;
#endif /* WITH_BAN */
    ctimer_set(&e->remove_timer, ENCOUNTER_LIFETIME, remove_encounter, e);
    list_add(encounter_list, e);
  }
  e->ALERT_HIM = 0;
}
/*---------------------------------------------------------------------------*/
static void
turn_radio_off_callback(void *packet)
{
  struct queue_list_item *p = packet;
  struct encounter *e;
  clock_time_t wait;

  /* encounter that woke us up */
  for(e = list_head(encounter_list); e != NULL; e = e->next) {
    if(rimeaddr_cmp(&p->dest, &e->neighbor)) {
      clock_time_t now;

      now = clock_time();
      wait = ((clock_time_t)(e->time - now)) % (PROBE_INTERVAL);
      break;
    }
  }
  if (e == NULL) {
    return;
  }

  if (e->turn_off_radio_timer_counter > 0) {
    if (e->turn_off_radio_timer_counter < 4) {
      int more_packets;
      struct queue_list_item *i;

      ctimer_set(&e->turn_on_radio_timer, wait, turn_radio_on_callback, packet);
      e->turn_off_radio_timer_counter++;
      print_numpackets();

      COOJA_DEBUG("missed encounter: postponing");
      more_packets = 1;
      while (more_packets) {
        more_packets = 0;
        for(i = list_head(queued_packets_list); i != NULL; i = list_item_next(i)) {
          if(rimeaddr_cmp(&i->dest, &e->neighbor)) {
            list_remove(queued_packets_list, i);
            list_add(pending_packets_list, i);
            COOJA_DEBUG("queue -> pending");
            more_packets = 1;
            break;
          }
        }
      }

      print_numpackets();

      if (is_triggering) {
        COOJA_DEBUG("missed encounter: postponing (is_triggering)");
      }
      if (is_competing_now()) {
        COOJA_DEBUG("missed encounter: postponing (is_competing)");
      }
      turn_radio_off();
      /*printf("missed encounter: postponing for %d\n", e->neighbor.u8[0]);*/
      return;
    }
    COOJA_DEBUG("lost encounter: resynchronizing");
    return;
  }
}
/*---------------------------------------------------------------------------*/
static void
turn_radio_on_callback(void *packet)
{
  struct queue_list_item *p = packet;
  struct queue_list_item *i;
  struct encounter *e;
  clock_time_t diff;
  int more_packets;

  /* encounter */
  for(e = list_head(encounter_list); e != NULL; e = e->next) {
    if(rimeaddr_cmp(&p->dest, &e->neighbor)) {
      break;
    }
  }
  if (e == NULL) {
    return;
  }

  /* postpone wakeup? */
  diff = clock_time() - etimer_expiration_time(&e->turn_on_radio_timer.etimer);

  /* callback was delayed */
  if (diff > 0) {
    ctimer_set(&e->turn_on_radio_timer, PROBE_INTERVAL-diff, turn_radio_on_callback, p);
    COOJA_DEBUG("postponed callback radio wakeup (delayed)");
    p->WAS_POSTPONED = 1;
    return;
  }
  /* radio is busy */
  if (NETSTACK_RADIO.receiving_packet()) {
    ctimer_set(&e->turn_on_radio_timer, PROBE_INTERVAL, turn_radio_on_callback, p);
    COOJA_DEBUG("postponed callback radio wakeup (receiving)");
    p->WAS_POSTPONED = 1;
    return;
  }
  /* we are probing for data */
  if (is_triggering) {
    ctimer_set(&e->turn_on_radio_timer, PROBE_INTERVAL, turn_radio_on_callback, p);
    COOJA_DEBUG("postponed callback radio wakeup (triggering)");
    p->WAS_POSTPONED = 1;
    return;
  }
  /* we are already competing elsewhere */
  if (is_competing_now()) {
    ctimer_set(&e->turn_on_radio_timer, PROBE_INTERVAL, turn_radio_on_callback, p);
    COOJA_DEBUG("postponed callback radio wakeup (competing)");
    p->WAS_POSTPONED = 1;
    return;
  }
  /* we are transmitting a broadcast */
  if (have_queued_broadcast()) {
    ctimer_set(&e->turn_on_radio_timer, PROBE_INTERVAL, turn_radio_on_callback, p);
    COOJA_DEBUG("postponed callback radio wakeup (bc tx)");
    p->WAS_POSTPONED = 1;
    return;
  }
  /* we will probe for data soon (random) */
#if 0
  if ((etimer_expiration_time(&probe_timer.etimer) - clock_time()) < 3) {
    /* randomly disable next probe, to avoid synchronously colliding probes */
    if (e->ignored == 0 && (random_rand()%100) < 50) {
      ctimer_set(&e->turn_on_radio_timer, PROBE_INTERVAL, turn_radio_on_callback, p);
      COOJA_DEBUG("postponed callback radio wakeup (probe soon)");
      p->WAS_POSTPONED = 1;
      e->ignored++;
      return;
    } else {
      COOJA_DEBUG("callback randomly disabled next outgoing probe");
      is_competing = 1;
      is_competing_time = clock_time();
      if (e->ignored) {
        COOJA_DEBUG("(he was previously ignored)");
      }
      e->ignored = 0;
    }
  }
  /* TODO allow only one UC-destination as well? */
#endif

  /* pending -> queue */
  more_packets = 1;
  while (more_packets) {
    more_packets = 0;
    for(i = list_head(pending_packets_list); i != NULL; i = list_item_next(i)) {
      if(rimeaddr_cmp(&i->dest, &e->neighbor)) {
        list_remove(pending_packets_list, i);
        list_add(queued_packets_list, i);
        COOJA_DEBUG("queued uc");
        more_packets = 1;
        break;
      }
    }
  }
  led_queued_broadcast();
  print_numpackets();

  if (num_packets_to_send() == 0) {
    /* no queued packets */
    return;
  }

  cc2420_set_channel(PROBE_CHANNEL);
  e->turn_off_radio_timer_counter++;
  ctimer_set(&e->turn_off_radio_timer, 3, turn_radio_off_callback, packet);
  turn_radio_on(TURN_RADIO_ON_REASON_CALLBACK);
}
/*---------------------------------------------------------------------------*/
/* This function goes through all encounters to see if it finds a
   matching neighbor. If so, we set a ctimer that will turn on the
   radio just before we expect the neighbor to send a probe packet. If
   we cannot find a matching encounter, we just turn on the radio.

   The outbound packet is put on either the pending_packets_list or
   the queued_packets_list, depending on if the packet should be sent
   immediately.
 */
static void
turn_radio_on_for_neighbor(rimeaddr_t *neighbor, struct queue_list_item *i)
{
  struct encounter *e;

  if(rimeaddr_cmp(neighbor, &rimeaddr_null)) {
    /* We have been asked to turn on the radio for a broadcast, so we
       just turn on the radio. */
    turn_radio_on(TURN_RADIO_ON_REASON_BC);
    list_add(queued_packets_list, i);
    led_queued_broadcast();
    return;
  }

#if WITH_ENCOUNTER_OPTIMIZATION
  /* We go through the list of encounters to find if we have recorded
     an encounter with this particular neighbor. If so, we can compute
     the time for the next expected encounter and setup a ctimer to
     switch on the radio just before the encounter. */
  for(e = list_head(encounter_list); e != NULL; e = e->next) {
    if(rimeaddr_cmp(neighbor, &e->neighbor)) {
      clock_time_t wait, now;

      /* We expect encounters to happen roughly every PROBE_INTERVAL time
     units. The next expected encounter is at time e->time +
     PROBE_INTERVAL. To compute a relative offset, we subtract with
     clock_time(). Because we are only interested in turning on
     the radio within the PROBE_INTERVAL period, we compute the waiting
     time with modulo PROBE_INTERVAL. */

      now = clock_time();
      wait = ((clock_time_t)(e->time - now)) % (PROBE_INTERVAL);

      /*      printf("now %d e %d e-n %d w %d %d\n", now, e->time, e->time - now, (e->time - now) % (PROBE_INTERVAL), wait);

      printf("Time now %lu last encounter %lu next expected encouter %lu wait %lu/%d (%lu)\n",
         (1000ul * (unsigned long)now) / CLOCK_SECOND,
         (1000ul * (unsigned long)e->time) / CLOCK_SECOND,
         (1000ul * (unsigned long)(e->time + PROBE_INTERVAL)) / CLOCK_SECOND,
         (1000ul * (unsigned long)wait) / CLOCK_SECOND, wait,
         (1000ul * (unsigned long)(wait + now)) / CLOCK_SECOND);*/

      /*      printf("Neighbor %d.%d found encounter, waiting %d ticks\n",
          neighbor->u8[0], neighbor->u8[1], wait);*/
      i->WAS_POSTPONED = 0;
      ctimer_set(&e->turn_on_radio_timer, wait, turn_radio_on_callback, i);
      list_add(pending_packets_list, i);
      return;
    }
  }
#endif /* WITH_ENCOUNTER_OPTIMIZATION */

  /* We did not find the neighbor in the list of recent encounters, so
     we just turn on the radio. */
  /*  printf("Neighbor %d.%d not found in recent encounters\n",
      neighbor->u8[0], neighbor->u8[1]);*/
  if (neighbor->u8[0] == 1) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 1");
  } else if (neighbor->u8[0] == 2) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 2");
  } else if (neighbor->u8[0] == 3) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 3");
  } else if (neighbor->u8[0] == 4) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 4");
  } else if (neighbor->u8[0] == 5) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 5");
  } else if (neighbor->u8[0] == 6) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 6");
  } else if (neighbor->u8[0] == 7) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 7");
  } else if (neighbor->u8[0] == 8) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 8");
  } else if (neighbor->u8[0] == 9) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 9");
  } else if (neighbor->u8[0] == 10) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 10");
  } else if (neighbor->u8[0] == 11) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 11");
  } else if (neighbor->u8[0] == 12) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 12");
  } else if (neighbor->u8[0] == 13) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 13");
  } else if (neighbor->u8[0] == 14) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 14");
  } else if (neighbor->u8[0] == 15) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 15");
  } else if (neighbor->u8[0] == 16) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 16");
  } else if (neighbor->u8[0] == 17) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 17");
  } else if (neighbor->u8[0] == 18) {
    COOJA_DEBUG("YYY NO_ENCOUNTER 18");
  } else {
    COOJA_DEBUG("YYY NO_ENCOUNTER ??");
  }
  turn_radio_on(TURN_RADIO_ON_REASON_NO_ENCOUNTER);
  list_add(queued_packets_list, i);
  led_queued_broadcast();
  return;
}
/*---------------------------------------------------------------------------*/
static int
prune_queued_packets(void)
{
  struct queue_list_item *i = NULL;
  for(i = list_head(queued_packets_list); i != NULL; i = list_item_next(i)) {
    if(i->removeme) {
      COOJA_DEBUG("pruned queued packet");
      ctimer_stop(&competition_timer);
      remove_queued_packet((void*)i->p_seq);
      return 1;
    }
  }
  return 0;
}
/*---------------------------------------------------------------------------*/
static int
deliver_mac_callbacks(void)
{
  struct queue_list_item *i = list_head(callback_packets_list);
  if (i == NULL) {
    return 0;
  }

  COOJA_DEBUG("delivering mac callback");

  if (!i->acked && !i->bc) {
    COOJA_DEBUG("XXX removing non-acked uc packet");
    print_numpackets();
  }

  if (i->bc) {
    mac_call_sent_callback(i->mac_callback, i->mac_callback_ptr, MAC_TX_OK, 1);
  } else if (i->acked) {
    mac_call_sent_callback(i->mac_callback, i->mac_callback_ptr, MAC_TX_OK, i->numtx);
  } else if (i->numtx == 0) {
    mac_call_sent_callback(i->mac_callback, i->mac_callback_ptr, MAC_TX_COLLISION, 0);
  } else {
    mac_call_sent_callback(i->mac_callback, i->mac_callback_ptr, MAC_TX_NOACK, i->numtx);
  }

  list_remove(callback_packets_list, i);
  memb_free(&queued_packets_memb, i);
  return 1;
}
/*---------------------------------------------------------------------------*/
static int
deliver_incoming_packets(void)
{
  struct queue_list_item *i = list_head(incoming_packets_list);
  if (i == NULL) {
    return 0;
  }

  COOJA_DEBUG("delivering buffered packet");
  list_remove(incoming_packets_list, i);
  queuebuf_to_packetbuf(i->packet);
  queuebuf_free(i->packet);
  NETSTACK_MAC.input();
  memb_free(&queued_packets_memb, i);
  return 1;
}
/*---------------------------------------------------------------------------*/
static uint16_t
busywait_until_sfd_false()
{
#undef UNTIL_MAX_SAMPLES
#define UNTIL_MAX_SAMPLES 900 /* TODO Calibrate */

  int samples=0;

  /* Busy-wait until SFD is false */
  LEDS_ON(LEDS_RED);
  while (NETSTACK_RADIO.receiving_packet()) {
    samples++;
    asm("nop");
    asm("nop");
    asm("nop");
    if (samples >= UNTIL_MAX_SAMPLES) {
      break;
    }
  }
  LEDS_OFF(LEDS_RED);

  if (samples >= UNTIL_MAX_SAMPLES) {
    ERROR("error: SFD sampling failed");
    progress_9++;
    return -1;
  }
  return samples;
}
/*---------------------------------------------------------------------------*/
static uint16_t
busywait_until_sfd_true()
{
#undef UNTIL_MAX_SAMPLES
#define UNTIL_MAX_SAMPLES 900 /* TODO Calibrate */

  int samples=0;

  /* Busy-wait until SFD is true */
  LEDS_ON(LEDS_ALL);
  while ((!NETSTACK_RADIO.receiving_packet()) && samples++ <= UNTIL_MAX_SAMPLES);
  LEDS_OFF(LEDS_ALL);

  if (samples >= UNTIL_MAX_SAMPLES) {
    progress_10++;
    COOJA_DEBUG("error: sfd never true");
    return -1;
  }
  return samples;
}
/*---------------------------------------------------------------------------*/
#if 0
static uint16_t
busywait_until_cca_false()
{
#undef UNTIL_MAX_SAMPLES
#define UNTIL_MAX_SAMPLES 250 /* TODO Calibrate: sim ~27. */

  int samples=0;

  /* Busy-wait until CCA is false */
  LEDS_ON(LEDS_ALL);
  while (cc2420_cca_fast() && samples++ <= UNTIL_MAX_SAMPLES);
  LEDS_OFF(LEDS_ALL);

  if (samples >= UNTIL_MAX_SAMPLES) {
    progress_11++;
    return -1;
  }
  return samples;
}
#endif
/*---------------------------------------------------------------------------*/
#if 0
static uint16_t
busywait_for_votes()
{
#undef UNTIL_MAX_SAMPLES
#define UNTIL_MAX_SAMPLES 700 /* TODO Calibrate */

  int cca_true=0;
  int cca_false=0;
  int count=0;

  LEDS_ON(LEDS_BLUE);
  while (count++ < UNTIL_MAX_SAMPLES) {
    if (cc2420_cca_fast()) {
      cca_true++;
    } else {
      cca_false++;
    }
  }
  LEDS_OFF(LEDS_BLUE);

  return cca_false;
}
#endif
/*---------------------------------------------------------------------------*/
static uint16_t
busywait_until_cca_true()
{
#undef UNTIL_MAX_SAMPLES
#define UNTIL_MAX_SAMPLES 800 /* TODO Calibrate */

  int samples=0;

  /* Busy-wait until CCA is true */
  LEDS_ON(LEDS_BLUE);
  while (!cc2420_cca_fast()) {
    samples++;
    if (samples >= UNTIL_MAX_SAMPLES) {
      break;
    }
  }
  LEDS_OFF(LEDS_BLUE);

  if (samples >= UNTIL_MAX_SAMPLES) {
    ERROR("error: CCA sampling failed");
    return -1;
  }

  return samples;
}
/*---------------------------------------------------------------------------*/
static int
rimac_wait(int req_bytes)
{
  int samples=0;

  while (req_bytes > 0) {
    if (!cc2420_cca_fast()) {
      return 0; /* detected energy */
    }
    req_bytes--;
    clock_delay(57);
  }
  return 1; /* winner */
}
/*---------------------------------------------------------------------------*/
static int
samples_to_bytes(uint16_t samples)
{
  if (samples < SAMPLES_MIN) {
    return -2;
  }
  /*printf("P --\n");*/
  /*printf("P got %d\n", samples);*/
  samples -= SAMPLES_MIN;
  /*printf("P -= %d\n", samples);*/
  samples /= SAMPLES_INTERVAL;
  /*printf("P /= %d\n", samples);*/
  /*printf("P ret %d\n", (samples*VOTE_INTERVAL));*/
  return samples*VOTE_INTERVAL;
}
/*---------------------------------------------------------------------------*/
/**
 * Trigger vote phase:
 * Allow others to compete for sending us a data packet.
 * This function returns:
 *  MAC_TX_OK if nobody competed (nobody want to send us data)
 *  MAC_TX_COLLISION if voting completed, a winner was elected and signalled
 *  MAC_TX_ERR if voting phase failed, such as due to unexpected radio traffic
 */
static int
trigger_vote(void)
{
  int size;
  int req_rssi;
  uint16_t cca_samples;

  watchdog_periodic();

  if (testmode_no_probes) {
    return MAC_TX_OK;
  }
  if (stop_sending_probes) {
    stop_sending_probes = 0;
    return MAC_TX_OK;
  }

  /* NOISE FLOOR x10 */
  NETSTACK_RADIO.on();
  req_rssi = cc2420_rssi();

  /* Send vote probe */
  preload_voteprobe(); /* Prepare for next voting round (they may have more data packets for us) */
  ASSERT_PRELOADED(TYPE_VOTE_PROBE, "error #1");
  if (debug_preloaded_type != TYPE_VOTE_PROBE) {
    COOJA_DEBUG("XXX TWIST ABORT #1");
    return MAC_TX_OK;
    //return MAC_TX_ERR;
  }
  NETSTACK_RADIO.transmit(0); /* With CCA? */
  debug_preloaded_type = TYPE_NULL;
  busywait_until_sfd_true(); /* wait for transmission to start */
  busywait_until_sfd_false(); /* wait for transmission to finish */
  COOJA_DEBUG("sent vote probe");
  progress_5++;


  /* RIMAC: Wait for a full packet, see anyone starts transmitting */
  if (testmode_rimac) {
    int traffic;
    int receiving;
    int timeout;

    /* Detect packet! */
    COOJA_DEBUG("RIMAC awaiting data");
    receiving = 0;
    traffic = 0;
    timeout = 80;
    clock_delay(200);
    while (timeout > 0) {
      clock_delay(200);
      if(!cc2420_cca_fast()) {
        traffic = 1;
        break;
      }
      timeout--;
    }

    if (traffic) {
      COOJA_DEBUG("RIMAC data detected");
      debug_preloaded_type = TYPE_NULL;
      return MAC_TX_COLLISION;
    }
    debug_preloaded_type = TYPE_NULL;
    COOJA_DEBUG("RIMAC no data detected");
    return MAC_TX_OK;
  }


  /* Await votes */
#if WITH_ADAPTIVE_REQUEST_PHASE
  {
    rtimer_clock_t wait_time;
    wait_time = RTIMER_NOW();
    wait_time += 20; /* XXX */
    //wait_time += 4; /* XXX Added 2011-03-17, Contiki timers changed */
    while (RTIMER_CLOCK_LT(RTIMER_NOW(),wait_time));
  }
  clock_delay(50); /* Extra CRC-specific delay XXX experimental */
  {
    /* XXX Must perform rssi sample here due to timing */
    /*req_rssi = cc2420_rssi_fast();*/
    /*req_rssi = cc2420_rssi_fast() - req_rssi;*/ /* SNR */
    cc2420_rssi_fast(); /* null */
  }
  if (cc2420_cca_fast()) {
    /* No incoming packet detected (no traffic) */
    if (testmode_print_requests) {
      printf("ERL %d -1 -1 ? ? %d\n", buf_voteprobes_counter, req_rssi);
    }
    COOJA_DEBUG("no vote detected");
    return MAC_TX_OK;
  }
  cca_samples = busywait_until_cca_true();
  if (cca_samples == -1) {
    COOJA_DEBUG("bad vote length estimation");
    if (testmode_print_requests) {
      printf("ERL %d -2 -2 ? ? %d\n", buf_voteprobes_counter, req_rssi);
    }
    COOJA_DEBUG("XXX TWIST ABORT #2");
    return MAC_TX_OK;
    //return MAC_TX_ERR;
  }
#else /* WITH_ADAPTIVE_REQUEST_PHASE */
  cca_samples = busywait_for_votes(); /* sample cca for entire vote period */
#endif /* WITH_ADAPTIVE_REQUEST_PHASE */

  COOJA_DEBUG("    *** VOTE PHASE DONE ***");
  size = samples_to_bytes(cca_samples);

  if (!testmode_no_cts && !testmode_rimac) {
    clock_delay(700); /* XXX Delay before sending signal */
  }
  COOJA_DEBUG("warn: flush 4.0");
  cc2420_flushrx(1);
  if (size == -2) {
    /* Bad size estimation (too many samples) */
    progress_6++;
    if (testmode_print_requests) {
      printf("ERL %d %d %d ? ? %d\n", buf_voteprobes_counter, size, cca_samples, req_rssi);
    }
    COOJA_DEBUG("XXX TWIST ABORT #3");
    return MAC_TX_OK;
    //return MAC_TX_ERR;
  }
  if (size < 0) {
    /* No incoming packet detected (too few samples) */
    if (testmode_print_requests) {
      printf("ERL %d %d %d ? ? %d\n", buf_voteprobes_counter, size, cca_samples, req_rssi);
    }
    return MAC_TX_OK;
  }

  /* Signal winner */
  if (!testmode_no_cts && !testmode_rimac) {
    preload_signal(size);
    ASSERT_PRELOADED(TYPE_SIGNAL, "error #2");
    if (debug_preloaded_type != TYPE_SIGNAL) { return MAC_TX_ERR; }
    COOJA_DEBUG("sending signal");

    NETSTACK_RADIO.transmit(0);
    busywait_until_sfd_true(); /* wait for transmission to start */
    busywait_until_sfd_false(); /* wait for transmission to finish */
    COOJA_DEBUG("sent signal");
    log_competition(&buf_signals, (rimeaddr_t*)&buf_voteprobes_counter, &rimeaddr_node_addr);
  }



  debug_preloaded_type = TYPE_NULL;
  progress_7++;

  /*return MAC_TX_OK;*/ /* Slow down... */
  if (testmode_print_requests) {
    printf("ERL %d %d %d ? ? %d\n", buf_voteprobes_counter, size, cca_samples, req_rssi);
  }
  return MAC_TX_COLLISION;
}
/*---------------------------------------------------------------------------*/
/**
 * Duty cycle the radio, and trigger voting phases. This function is called
 * repeatedly by a ctimer. The function restart_dutycycle() is used to
 * (re)start the duty cycling.
 */
static int
dutycycle(void *ptr)
{
#define NUM_PREVOTE_CCA_CHECKS 0 /* CCA before probes? */
  struct ctimer *t = ptr;
  static int vote_outcome = 0;
#if NUM_PREVOTE_CCA_CHECKS > 0
  static int scan_count;
#endif /* NUM_PREVOTE_CCA_CHECKS */
  PT_BEGIN(&dutycycle_pt);

  ctimer_set(&probe_timer, off_time, (void (*)(void *))dutycycle, t);
  PT_YIELD_UNTIL(&dutycycle_pt, ctimer_expired(&probe_timer));

  while(1) {

    /* -- READ INCOMING DATA PACKETS -- */

    if (!is_competing_now()) {
      cc2420_set_channel(PROBE_CHANNEL);
    }
#if NUM_PREVOTE_CCA_CHECKS > 0
    /* Await no network activity before sending probe */
    scan_count = 0;
    do {
      if (is_competing_now()) {
        break;
      }

      turn_radio_off();
      clock_delay(450); /* TODO Calibrate on HW */
      turn_radio_on(TURN_RADIO_ON_REASON_TRIGGER_VOTE);

      scan_count++;
      if (!NETSTACK_RADIO.channel_clear()) {
        COOJA_DEBUG("detected network activity, resetting scan count");
        scan_count = 0;
      }
    } while (scan_count < NUM_PREVOTE_CCA_CHECKS);
#endif /* NUM_PREVOTE_CCA_CHECKS */

    if (!is_competing_now() && !testmode_no_probes) {
      int traffic;
      int receiving;
      int timeout;

      is_triggering = 1;

      /* Trigger voting phases and receive all incoming data packets */
#if WITH_INITIAL_DATAPROBES
      /*COOJA_DEBUG("sending data probe");*/

      preload_dataprobe();
      turn_radio_on(TURN_RADIO_ON_REASON_TRIGGER_VOTE);
      NETSTACK_RADIO.transmit(0);
      debug_preloaded_type = TYPE_NULL;
      busywait_until_sfd_true(); /* wait for transmission to start */
      busywait_until_sfd_false(); /* wait for transmission to finish */
#if WITH_MULTICHANNEL
      cc2420_set_channel(my_data_channel);
#else /* WITH_MULTICHANNEL */
      cc2420_set_channel(PROBE_CHANNEL);
#endif /* WITH_MULTICHANNEL */

      receiving = 0;
      traffic = 0;
      timeout = 12;
      clock_delay(200);
      while (timeout > 0) {
        clock_delay(200);
        if(!cc2420_cca_fast()) {
          traffic = 1;
        }
        if (NETSTACK_RADIO.pending_packet() || NETSTACK_RADIO.receiving_packet()) {
          receiving = 1;
          traffic = 1;
          break;
        }
        timeout--;
      }

      progress_16++;
      if (!traffic) {
        /*COOJA_DEBUG("no traffic detected");*/
        vote_outcome = MAC_TX_OK;
        progress_15++;
      } else {
        if (receiving) {
          COOJA_DEBUG("traffic detected: receiving data now");
          timeout = 25;
          while (NETSTACK_RADIO.receiving_packet() &&
              !NETSTACK_RADIO.pending_packet() &&
              timeout > 0) {
            clock_delay(200);
            timeout--;
          }
          clock_delay(20);
          if (NETSTACK_RADIO.pending_packet()) {
            COOJA_DEBUG("traffic detected: received data");
            ctimer_set(t, 1, (void (*)(void *))dutycycle, t);
            PT_YIELD(&dutycycle_pt);
            if (ctimer_expired(t)) {
              COOJA_DEBUG("data probe: next round by timer");
            } else {
              COOJA_DEBUG("data probe: next round by data");
            }
            ctimer_stop(t);
          } else {
            COOJA_DEBUG("traffic detected: but no data pending");
          }
        } else {
          COOJA_DEBUG("traffic detected: no reception, collision?");
          cc2420_flushrx(5);
          timeout = 20;
          while (!cc2420_cca_fast() &&
              timeout > 0) {
            clock_delay(200);
            timeout--;
          }
        }

        /* Receive next radio packet by vote */
        dint();
        vote_outcome = trigger_vote();
        eint();
      }
#else /* WITH_INITIAL_DATAPROBES */
      dint();
      vote_outcome = trigger_vote();
      eint();
#endif /* WITH_INITIAL_DATAPROBES */

      /* Did anyone vote? */
      while (!testmode_print_requests && vote_outcome == MAC_TX_COLLISION) {
        int traffic;
        int receiving;
        int timeout;

        /*if (clock_repair()) {
          COOJA_DEBUG("warning: repaired clock (pre)");
        }*/

        receiving = 0;
        traffic = 0;
        timeout = 15;
        while (timeout > 0) {
          clock_delay(200);
          if(!cc2420_cca_fast()) {
            traffic = 1;
          }
          if (NETSTACK_RADIO.receiving_packet()) {
            if(!cc2420_cca_fast()) {
              traffic = 1;
            }
            receiving = 1;
            break;
          }
          timeout--;
        }
        if (traffic || receiving) {
          if (receiving) {
            COOJA_DEBUG("traffic detected: receiving data now");
            timeout = 25;
            while (NETSTACK_RADIO.receiving_packet() &&
                !NETSTACK_RADIO.pending_packet() &&
                timeout > 0) {
              clock_delay(200);
              timeout--;
            }
            if (NETSTACK_RADIO.pending_packet()) {
              COOJA_DEBUG("traffic detected: received data");
              ctimer_set(t, 1, (void (*)(void *))dutycycle, t);
              PT_YIELD(&dutycycle_pt);
              if (ctimer_expired(t)) {
                COOJA_DEBUG("vote probe: next round by timer");
              } else {
                COOJA_DEBUG("vote probe: next round by data");
              }
              ctimer_stop(t);
            } else {
              COOJA_DEBUG("traffic detected: but no data pending");
            }
          } else {
            COOJA_DEBUG("traffic detected: no reception, collision?");
            cc2420_flushrx(5);
            timeout = 20;
            while (!cc2420_cca_fast() &&
                timeout > 0) {
              clock_delay(200);
              timeout--;
            }
          }
        } else {
          COOJA_DEBUG("no data traffic, immediately triggering new round!");
        }

        /*if (clock_repair()) {
          COOJA_DEBUG("warning: repaired clock (post)");
        }*/


        {
          /* XXX MAKE SURE WE DO NOT STAY IN HERE TOO LONG! */
          clock_time_t diff;
          diff =
              clock_time() -
              (probe_timer.etimer.timer.start + probe_timer.etimer.timer.interval);
          if (diff > 4*PROBE_INTERVAL/8) {
            vote_outcome = MAC_TX_OK;
            break;
          }
        }


        /* Trigger another voting round, no need to scan for network activity */
        dint();
        vote_outcome = trigger_vote();
        eint();
      }
      cc2420_set_channel(PROBE_CHANNEL);

      turn_radio_off();

      if (!testmode_print_requests && vote_outcome == MAC_TX_ERR) {
        /* Restart probing immediately */
        COOJA_DEBUG("bad voting phase");
        vote_outcome = MAC_TX_OK;
        //continue;
      }
    } else {
      COOJA_DEBUG("no data probe this round (competing)");
    }

    is_triggering = 0;
    is_competing = 0; /* reset competing flag */

    preload_vote(); /* prepare for next phase: sending data packets */

    /* Deliver data packets to applications */
    while (prune_queued_packets());
    while (deliver_incoming_packets());
    while (deliver_mac_callbacks());


    /* -- SEND OUTGOING DATA PACKETS -- */

    preload_vote();

    if(num_packets_to_send() > 0) {
      /* We have enqueued packets: keep radio on */
      turn_radio_on(TURN_RADIO_ON_REASON_MORE_PACKETS);
    } else {
      /* If we have no outgoing packets, so we turn the radio off. */
      turn_radio_off();
    }

    {
      clock_time_t diff;
      diff =
          clock_time() -
          (probe_timer.etimer.timer.start + probe_timer.etimer.timer.interval);
      if (diff > progress_14) {
        progress_14 = (int) (diff&0xffff);
      }
    }
    ctimer_reset(&probe_timer);
    PT_YIELD_UNTIL(&dutycycle_pt, ctimer_expired(&probe_timer));
  }

  PT_END(&dutycycle_pt);
}
/*---------------------------------------------------------------------------*/
static void
restart_dutycycle(clock_time_t initial_wait)
{
  PT_INIT(&dutycycle_pt);
  ctimer_set(&timer, initial_wait, (void (*)(void *))dutycycle, &timer);
}
/*---------------------------------------------------------------------------*/
static uint16_t p_seq_counter = 0;
static void
send_packet(mac_callback_t sent, void *ptr)
{
  static uint8_t seq_counter = 0; /* Sequence number counter */
  struct strawman_hdr hdr;
  clock_time_t timeout;
  uint8_t is_broadcast = 0;
  struct queue_list_item *i;

  rimeaddr_copy(&hdr.sender, &rimeaddr_node_addr);
  rimeaddr_copy(&hdr.receiver, packetbuf_addr(PACKETBUF_ADDR_RECEIVER));
  if(rimeaddr_cmp(&hdr.receiver, &rimeaddr_null)) {
    is_broadcast = 1;
  }
  hdr.type = TYPE_DATA;

  /* incrementing sequence number (0-127) */
  hdr.seq = seq_counter;
  seq_counter++;
  seq_counter &= 0x7f;

  if (is_broadcast && testmode_instant_broadcasts) {
    NETSTACK_RADIO.prepare("INSTANTBROADCAST", 17);
    NETSTACK_RADIO.transmit(0);
    mac_call_sent_callback(sent, ptr, MAC_TX_NOACK, 1);
    return;
  }

  packetbuf_hdralloc(sizeof(struct strawman_hdr));
  memcpy(packetbuf_hdrptr(), &hdr, sizeof(struct strawman_hdr));

  packetbuf_compact();
  PRINTF("%d.%d: queueing packet to %d.%d, channel %d\n",
      rimeaddr_node_addr.u8[0], rimeaddr_node_addr.u8[1],
      hdr.receiver.u8[0], hdr.receiver.u8[1],
      packetbuf_attr(PACKETBUF_ATTR_CHANNEL));

  i = memb_alloc(&queued_packets_memb);
  if (i == NULL) {
    ERROR("error #1 no room, dropping outgoing packet");
    mac_call_sent_callback(sent, ptr, MAC_TX_ERR_FATAL, 0);
    return;
  }
  i->packet = queuebuf_new_from_packetbuf();
  if(i->packet == NULL) {
    ERROR("error #2 no room, dropping outgoing packet");
    memb_free(&queued_packets_memb, i);
    mac_call_sent_callback(sent, ptr, MAC_TX_ERR_FATAL, 0);
    return;
  }
  rimeaddr_copy(&i->dest, &hdr.receiver);

  if(is_broadcast) {
    timeout = PACKET_LIFETIME;
    i->bc = 1;
  } else {
    timeout = UNICAST_TIMEOUT;
    i->bc = 0;
  }
  rimeaddr_copy(&i->bc_acked_by, &rimeaddr_null);

  p_seq_counter++;
  i->acked = 0;
  i->mac_callback = sent;
  i->mac_callback_ptr = ptr;
  i->numtx = 0;
  i->p_seq = p_seq_counter;
  i->removeme = 0;
  ctimer_set(&i->removal_timer, timeout, remove_queued_packet, (void*)i->p_seq);

  /* Wait for a probe packet from a neighbor. The actual packet
       transmission is handled by the read_packet() function,
       which receives the probe from the neighbor. */
  turn_radio_on_for_neighbor(&hdr.receiver, i);
}
/*---------------------------------------------------------------------------*/
static void
packet_input(void)
{
  struct strawman_hdr *hdr;
  struct queue_list_item *i;

  if (packetbuf_datalen() < sizeof(struct strawman_hdr)) {
    return;
  }

  hdr = packetbuf_dataptr();
  packetbuf_hdrreduce(sizeof(struct strawman_hdr));

#if REQ_COMPETE_NEXT_BC
  if (((char*)hdr)[0] == 'I') {
    if (num_packets_to_send() != 0) {
      COOJA_DEBUG("ERROR num packets");
      compete_next = 0;
    } else {
      strawman_callback();
      leds_on(LEDS_RED);
      compete_next = 1;
      COOJA_DEBUG("YYY compete_next = 1");
    }
    return;
  }
#endif

  if(hdr->type == TYPE_VOTE_PROBE || hdr->type == TYPE_DATA_PROBE) {
    /* Double-check that ack was handled.
     * If SPI was busy, this may not have been done in the interrupt... */
    handle_ack(hdr);
    return;
  }
  if(hdr->type != TYPE_DATA) {
    /* Ignore non-data packets */
    return;
  }

  /* XXX Potential bug, broadcasts do not exist! */
  if(rimeaddr_cmp(&hdr->receiver, &rimeaddr_null)) {
    COOJA_DEBUG("XXX received data without destination!");
    return;
  }

  /* Filter on destination */
  if(!rimeaddr_cmp(&hdr->receiver, &rimeaddr_null)) {
    if(!rimeaddr_cmp(&hdr->receiver, &rimeaddr_node_addr)) {
      /* Not broadcast, nor unicast for for us */
      PRINTF("%d.%d: data not for us from %d.%d\n",
          rimeaddr_node_addr.u8[0], rimeaddr_node_addr.u8[1],
          hdr->sender.u8[0], hdr->sender.u8[1]);
      return;
    }
    packetbuf_set_addr(PACKETBUF_ADDR_RECEIVER, &hdr->receiver);
  }
  packetbuf_set_addr(PACKETBUF_ADDR_SENDER, &hdr->sender);

  progress_8++;

  if (testmode_print_requests) {
    printf("ERL %d ? ? 1 %d ?\n", buf_voteprobes_counter, (int)((char*)&hdr->sender)[0]);
  }

  /* XXX Experimental: log competitions we receive data in */
  log_competition(&buf_data, &hdr->ack, &rimeaddr_node_addr);

  if (testmode_discard_data) {
    ERROR("testmode_discard_data: discarding");
    prepare_next_ack(hdr);
#if 0
    if (!ringbuf_put(&buf_data, (uint8_t)((char*)packetbuf_dataptr())[50])) {
      COOJA_DEBUG("XXX buf_data full!");
    }
#endif

#if WITH_QUICK_ROUNDS
  COOJA_DEBUG("triggering next voting round");
  dutycycle(&timer);
#endif /* WITH_QUICK_ROUNDS */
    return;
  }

  /* Buffer data packet to be handled later.
   * Delivering a data packet right now may induce timing interference */
  i = memb_alloc(&queued_packets_memb);
  if(i == NULL) {
    ERROR("error #0 panic delivery (slows down throughput)");

    /* Prepare future data ack: data source+seq */
    prepare_next_ack(hdr);

    NETSTACK_MAC.input();

#if WITH_QUICK_ROUNDS
    if (is_triggering) {
      COOJA_DEBUG("triggering next voting round");
      dutycycle(&timer);
    }
#endif /* WITH_QUICK_ROUNDS */
    return;
  }
  if(i == NULL) {
    ERROR("error #1 no room, dropping incoming packet (#1)");
    stop_sending_probes = 1;
    return;
  }
  i->packet = queuebuf_new_from_packetbuf();
  if(i->packet == NULL) {
    ERROR("error #2 no room, dropping incoming packet (#2)");
    stop_sending_probes = 1;
    memb_free(&queued_packets_memb, i);
    return;
  }
  list_add(incoming_packets_list, i);
  COOJA_DEBUG("incoming data packet ready for application delivery");

  /* Prepare future data ack: data source+seq */
  prepare_next_ack(hdr);

#if WITH_QUICK_ROUNDS
  if (is_triggering) {
    COOJA_DEBUG("triggering next voting round");
    dutycycle(&timer);
  }
#endif /* WITH_QUICK_ROUNDS */
}
/*---------------------------------------------------------------------------*/
static int
on(void)
{
  strawman_is_on = 1;
  COOJA_DEBUG("TURN_RADIO_ON_STATIC");
  return NETSTACK_RADIO.on();
}
/*---------------------------------------------------------------------------*/
static int
off(int keep_radio_on)
{
  strawman_is_on = 0;
  if(keep_radio_on) {
    if (testmode_always_request || testmode_print_request_rssi) {
      return 1;
    }
    return NETSTACK_RADIO.on();
  } else {
    cc2420_set_channel(PROBE_CHANNEL);
    ctimer_stop(&probe_timer);
    return NETSTACK_RADIO.off();
  }
  return 1;
}
/*---------------------------------------------------------------------------*/
static unsigned short
channel_check_interval(void)
{
  return PROBE_INTERVAL;
}
/*---------------------------------------------------------------------------*/
static int
cit_interrupt_handler(uint8_t* hdr, uint16_t delayed){
  static rimeaddr_t just_voted_for;
  static int just_voted_for_len = -1;
  struct queue_list_item *i;
  struct strawman_hdr *rxhdr = (struct strawman_hdr*) hdr;
  struct strawman_hdr *qhdr = NULL;
  clock_time_t reception_time;
  rtimer_clock_t processing_time;
  struct encounter *e;

#if REQ_COMPETE_NEXT_BC
  if (!compete_next) {
    COOJA_DEBUG("YYY !compete_next");
    preload_vote(); /* new round - new random */
    return 0;
  }
#endif

  /* Handling probe in interrupt for deterministic delays */
  processing_time = RTIMER_NOW();
  reception_time = clock_time();

  /* rxhdr->src: probe source */
  /* rxhdr->ack: acked data packet source - may be us */

  if (testmode_dont_compete &&
      (rxhdr->type == TYPE_DATA_PROBE ||
      rxhdr->type == TYPE_VOTE_PROBE)) {
    ERROR("testmode: dont compete mode");
    preload_vote(); /* new round - new random */
    return 0;
  }

  if (rxhdr->type != TYPE_DATA_PROBE &&
      rxhdr->type != TYPE_VOTE_PROBE &&
      rxhdr->type != TYPE_VOTE &&
      rxhdr->type != TYPE_SIGNAL &&
      rxhdr->type != TYPE_DATA) {
    ERROR("error: received unknown type, dropping packet");
    preload_vote(); /* new round - new random */
    return 0;
  }

  progress_1++;

#if WITH_INITIAL_DATAPROBES
  if(rxhdr->type == TYPE_DATA_PROBE) {
#if REQ_COMPETE_NEXT_BC
    if (compete_next == 1) {
      compete_next = 2;
      COOJA_DEBUG("YYY compete_next = 2");
      req_start_time = RTIMER_NOW();
      req_probes_seen = 0;
      leds_on(LEDS_ALL);
    }
#endif

    /* Register encounter */
    /* XXX Increase clock resolution to avoid long waiting times (~10ms) */
    register_encounter(&rxhdr->sender, reception_time-1);
  }
#else /* WITH_INITIAL_DATAPROBES */
  if(rxhdr->type == TYPE_VOTE_PROBE) {
    /* Register encounter (will drift with subsequent probes) */
    register_encounter(&rxhdr->sender, reception_time);
  }
#endif /* WITH_INITIAL_DATAPROBES */

  e = get_encounter(&rxhdr->sender);
#if WITH_BAN
    // XXX FROS CHECK BANNED FLAG
  if (e->banned && (rxhdr->type == TYPE_DATA_PROBE || rxhdr->type == TYPE_VOTE_PROBE)) {
    COOJA_DEBUG("XXXXX is banned, ignore");
    /* Nothing to do */
    preload_vote(); /* new round - new random */
    return 0;
  }
#endif /* WITH_BAN */

  if(rxhdr->type != TYPE_VOTE_PROBE
      && rxhdr->type != TYPE_DATA_PROBE
      && rxhdr->type != TYPE_SIGNAL) {
    /* Nothing to do */
    preload_vote(); /* new round - new random */
    return 0;
  }

  if(rxhdr->type != TYPE_SIGNAL && num_packets_to_send() <= 0) {
    /* Nothing to do */
    COOJA_DEBUG("warn: flush 1");
    /* TODO FIX cc2420.c peeking */
    cc2420_flushrx(5);  /* avoid filling up on probes only... */
    preload_vote(); /* new round - new random */
    return 0;
  }

  /* TODO Handle acks in both DATA_PROBEs and VOTE_PROBEs */
  if(rxhdr->type == TYPE_VOTE_PROBE) {
#if REQ_COMPETE_NEXT_BC
    req_probes_seen++;
#endif

    handle_ack(rxhdr);
    turn_radio_off();
  }

  /* Voting phase:
   * Should we compete? Do we have data for probe source? */
  /* TODO Handle broadcast packets */
  /* TODO Optimize critical path */
  for(i = list_head(queued_packets_list); i != NULL; i = i->next) {
    qhdr = queuebuf_dataptr(i->packet);
    if(rimeaddr_cmp(&qhdr->receiver, &rimeaddr_null)) {
      /* Compete unless last ack was from probe source */
      if (testmode_limit_bc_tx && i->numtx >= TESTMODE_LIMIT_BC_TX_NUM) {
        COOJA_DEBUG("maximum broadcast transmissions already!");
        qhdr = NULL;
      } else if (!rimeaddr_cmp(&rxhdr->sender, &i->bc_acked_by)) {
        /* Compete */
        /*COOJA_DEBUG("competing with broadcast);*/
        break;
      } else {
        COOJA_DEBUG("have broadcast that was already acked by probe source!");
        qhdr = NULL;
      }
    } else if(rimeaddr_cmp(&qhdr->receiver, &rxhdr->sender)) {
      /* Compete */
      break;
    } else {
      qhdr = NULL;
    }
  }

#if 1
  /* Avoid competing if log buffers are almost full */
  if(qhdr != NULL && rxhdr->type == TYPE_VOTE_PROBE && ringbuf_elements(&buf_competitions) > 250) {
    COOJA_DEBUG("XXX competition buffers full, no competition this round");
    qhdr = NULL;
  }
#endif

  if (qhdr == NULL) {
    cc2420_set_channel(PROBE_CHANNEL);
    preload_vote(); /* new round - new random */
    is_competing = 0;
    COOJA_DEBUG("no header, returning");
    turn_radio_off();
    return 0;
  }

  is_competing = 1;
  is_competing_time = clock_time();

#if WITH_MULTICHANNEL
  if(rxhdr->type == TYPE_DATA_PROBE) {
    int channel;
    rimeaddr_copy((rimeaddr_t*)&channel, &rxhdr->receiver);
    cc2420_set_channel(channel);
  }
#endif /* WITH_MULTICHANNEL */

  //////////////////////////////////////////////

  /* PROBE: Let's compete for this packet. (RIMAC MODE) */
  if (rxhdr->type == TYPE_VOTE_PROBE && testmode_rimac) {
    struct strawman_hdr *txhdr = queuebuf_dataptr(i->packet);
    int len;
    int winner;

    /* TODO Preload data packet here, maybe increase synch wait if big */
    { /* TEST */
      rimeaddr_copy(&txhdr->ack, &rxhdr->receiver);
    }
    NETSTACK_RADIO.prepare(queuebuf_dataptr(i->packet), queuebuf_datalen(i->packet));
    COOJA_DEBUG("data packet preloaded (rimac)");

    /* Synchronize start of wait */
    processing_time += 10; /* XXX */
    if (!RTIMER_CLOCK_LT(RTIMER_NOW(),processing_time)) {
      COOJA_DEBUG("warning: we missed the synch deadline!");
    }
    while (RTIMER_CLOCK_LT(RTIMER_NOW(),processing_time));

    COOJA_DEBUG("    *** SLEEPING ***");
    len = 112 - get_random_length();
    winner = rimac_wait(len); /* 7 bytes correspond to 320us + overhead */

    if (winner) {
      COOJA_DEBUG("      -- WINNER (rimac) -- ");
    } else {
      COOJA_DEBUG(" rimac: we lost");
    }

    if (!winner) {
      preload_vote(); /* new round - new random */
      rimeaddr_copy(&competition_neighbor, &rxhdr->sender);
      process_poll(&competition_timout_process);
      return 0;
    }

    COOJA_DEBUG("data packet tx (rimac)");
    NETSTACK_RADIO.transmit(0); /* send data */
    debug_preloaded_type = TYPE_NULL;
    busywait_until_sfd_true(); /* wait for transmission to start */
    busywait_until_sfd_false(); /* wait for transmission to finish */
    i->numtx = i->numtx + 1;
    progress_4++;

    if (winner) {
      log_competition(&buf_wins, &rxhdr->receiver, &just_voted_for);
    }

    /* Reset last competition */
    rimeaddr_copy(&just_voted_for, &rimeaddr_null);
    just_voted_for_len = -1;

    cc2420_flushrx(-1); /* potentially corrupted FIFO from vote phase */
    preload_vote(); /* new round - new random */
    rimeaddr_copy(&competition_neighbor, &rxhdr->sender);
    process_poll(&competition_timout_process);
    return 0;
  }

  //////////////////////////////////////////////

  /* PROBE: Let's compete for this packet. */
  if (rxhdr->type == TYPE_VOTE_PROBE) {
    struct strawman_hdr *txhdr = queuebuf_dataptr(i->packet);

    /* Compete */
    COOJA_DEBUG("    *** COMPETING ***");
    ASSERT_PRELOADED(TYPE_VOTE, "error #3");
    if (debug_preloaded_type != TYPE_VOTE) {
      preload_vote(); /* new round - new random */
      rimeaddr_copy(&competition_neighbor, &rxhdr->sender);
      process_poll(&competition_timout_process);
      return 0;
    }

    /* Synchronize start of request packets */
    processing_time += 10; /* XXX */
    if (!RTIMER_CLOCK_LT(RTIMER_NOW(),processing_time)) {
      COOJA_DEBUG("warning: we missed the synch deadline!");
    }
    while (RTIMER_CLOCK_LT(RTIMER_NOW(),processing_time));
    COOJA_DEBUG("    *** COMPETING (synch) ***");

    NETSTACK_RADIO.transmit(0); /* send vote packet */
    debug_preloaded_type = TYPE_NULL;

    /* Save current competition info */
    rimeaddr_copy(&just_voted_for, &rxhdr->sender);
    just_voted_for_len = last_vote_len;

    /* XXX Experimental: log competitions we participate in */
    log_competition(&buf_competitions, &rxhdr->receiver, &just_voted_for);

    rimeaddr_copy(&competition_neighbor, &rxhdr->sender);
    process_poll(&competition_timout_process);

#if WITH_BAN
    // XXX FROS INCREASE BANNED_COMP
    {
      if (e != NULL) {
        COOJA_DEBUG("XXX FROS inc banned comp");
        e->banned_comp++;
      }
    }
#endif /* WITH_BAN */

#if WITH_ADAPTIVE_REQUEST_PHASE
    /* Wait until all votes packets are transmitted */
    busywait_until_sfd_true(); /* wait for transmission to start */
    busywait_until_sfd_false(); /* wait for transmission to finish */
    cc2420_flushrx(95); /* potentially corrupted FIFO from vote phase */
#else /* WITH_ADAPTIVE_REQUEST_PHASE */
    /* Wait until all votes packets are transmitted */
    busywait_for_votes(); /* sample cca for entire vote period */
    cc2420_flushrx(95); /* potentially corrupted FIFO from vote phase */
#endif /* WITH_ADAPTIVE_REQUEST_PHASE */
    progress_2++;
    COOJA_DEBUG("    *** COMPETING DONE ***");

    /* SIGNAL PACKET ARRIVES */
    if (testmode_no_cts) {
      int winner = 1;

      cc2420_rssi();
      winner = cc2420_cca_fast();

      if (winner) {
        log_competition(&buf_wins, &rxhdr->receiver, &just_voted_for);
      }

      /* Reset last competition */
      rimeaddr_copy(&just_voted_for, &rimeaddr_null);
      just_voted_for_len = -1;

      if (!winner) {
        preload_vote(); /* new round - new random */
        rimeaddr_copy(&competition_neighbor, &rxhdr->sender);
        process_poll(&competition_timout_process);
        return 0;
      }

      COOJA_DEBUG("      -- WINNER (no cts) -- ");

      /* Winner! */
      { /* TEST */
        rimeaddr_copy(&txhdr->ack, &rxhdr->receiver);
      }
      if (i->bc) { /* XXX only send broadcast to prober */
        rimeaddr_copy(&txhdr->receiver, &rxhdr->sender);
      }
      NETSTACK_RADIO.prepare(queuebuf_dataptr(i->packet), queuebuf_datalen(i->packet));
      if (i->bc) { /* XXX only send broadcast to prober */
        rimeaddr_copy(&txhdr->receiver, &rimeaddr_null);
      }
      debug_preloaded_type = TYPE_DATA;
      COOJA_DEBUG("data packet preloaded");

      ASSERT_PRELOADED(TYPE_DATA, "error #4");
      if (debug_preloaded_type != TYPE_DATA) {
        preload_vote(); /* new round - new random */
        rimeaddr_copy(&competition_neighbor, &rxhdr->sender);
        process_poll(&competition_timout_process);
        return 0;
      }
      COOJA_DEBUG("data packet tx (no cts)");
      NETSTACK_RADIO.transmit(0); /* send data */
      debug_preloaded_type = TYPE_NULL;
      busywait_until_sfd_true(); /* wait for transmission to start */
      busywait_until_sfd_false(); /* wait for transmission to finish */
      i->numtx = i->numtx + 1;
      progress_4++;

      cc2420_flushrx(-1); /* potentially corrupted FIFO from vote phase */
      preload_vote(); /* new round - new random */
      rimeaddr_copy(&competition_neighbor, &rxhdr->sender);
      process_poll(&competition_timout_process);
      return 1;
    }

    /* ------------ TEST MODE ------------ */
    /*if (testmode_always_request) {
      uint16_t tmp;
      rimeaddr_copy((rimeaddr_t*)&tmp, &rxhdr->receiver);
      printf("ARL %d %d\n", tmp, just_voted_for_len);
    }*/

    /* Let's hope for a signal packet */
    preload_vote(); /* new round - new random */
    rimeaddr_copy(&competition_neighbor, &rxhdr->sender);
    process_poll(&competition_timout_process);
    return 0;
  }

  /* SIGNAL: Check whether we won. */
  if (rxhdr->type == TYPE_SIGNAL) {
    int winner = 1;
    int size;
    struct strawman_hdr *txhdr = queuebuf_dataptr(i->packet);

    /*COOJA_DEBUG("received signal");*/

    /* Signal packet delay tells us whether we won the vote */
    /* TODO Send vote probes with data counter to avoid flooding */
    rimeaddr_copy((rimeaddr_t *)&size, &rxhdr->receiver);
    /*printf("recv signal: addr %u.%u vs %u.%u, len %i vs %i\n",
            just_voted_for.u8[0], just_voted_for.u8[1],
            rxhdr->sender.u8[0], rxhdr->sender.u8[1],
            just_voted_for_len,
            size
        );*/
    if (!rimeaddr_cmp(&just_voted_for, &rxhdr->sender)) {
      COOJA_DEBUG("signal: incorrect source");
      winner = 0;
    }
    /*printf("diff %d\n", DIFF(size, just_voted_for_len));*/
    if (DIFF(size, just_voted_for_len) > THRESHOLD_BYTES) {
      COOJA_DEBUG("signal: incorrect size (we lost)");
      //progress_12 = DIFF(size, just_voted_for_len);
      winner = 0;
    }

    /* XXX Experimental: log competitions we win */
    if (winner) {
      log_competition(&buf_wins, &rxhdr->ack, &just_voted_for);
    }

    /* Reset last competition */
    rimeaddr_copy(&just_voted_for, &rimeaddr_null);
    just_voted_for_len = -1;

    if (!winner) {
      preload_vote(); /* new round - new random */
      rimeaddr_copy(&competition_neighbor, &rxhdr->sender);
      process_poll(&competition_timout_process);
      return 0;
    }

    COOJA_DEBUG("      -- WINNER -- ");
    progress_3++;

    /* Winner! */
    /* TEST */
    rimeaddr_copy(&txhdr->ack, &rxhdr->ack);

    if (i->bc) { /* XXX only send broadcast to prober */
      rimeaddr_copy(&txhdr->receiver, &rxhdr->sender);
    }
    NETSTACK_RADIO.prepare(queuebuf_dataptr(i->packet), queuebuf_datalen(i->packet));
    if (i->bc) { /* XXX only send broadcast to prober */
      rimeaddr_copy(&txhdr->receiver, &rimeaddr_null);
    }
    debug_preloaded_type = TYPE_DATA;
    COOJA_DEBUG("data packet preloaded");

    ASSERT_PRELOADED(TYPE_DATA, "error #4");
    if (debug_preloaded_type != TYPE_DATA) {
      preload_vote(); /* new round - new random */
      rimeaddr_copy(&competition_neighbor, &rxhdr->sender);
      process_poll(&competition_timout_process);
      return 0;
    }
    COOJA_DEBUG("data packet tx");
    NETSTACK_RADIO.transmit(0); /* send data */
    debug_preloaded_type = TYPE_NULL;
    busywait_until_sfd_true(); /* wait for transmission to start */
    busywait_until_sfd_false(); /* wait for transmission to finish */
    i->numtx = i->numtx + 1;
    progress_4++;
    progress_12++;

#if WITH_BAN
    {
      if (e != NULL) {
        // XXX FROS DECREASE BANNED_COMP
        COOJA_DEBUG("XXX FROS dec banned comp");
        e->banned_comp = 0;
        // XXX FROS INCREASE BANNED_WINS
        COOJA_DEBUG("XXX FROS inc banned wins");
        e->banned_wins++;
      }
    }
#endif /* WITH_BAN */


    cc2420_flushrx(-1); /* potentially corrupted FIFO from vote phase */
    preload_vote(); /* new round - new random */
    rimeaddr_copy(&competition_neighbor, &rxhdr->sender);
    process_poll(&competition_timout_process);
    return 1;
  }

  /* DATA PROBE */
  if (rxhdr->type == TYPE_DATA_PROBE) {
    struct strawman_hdr *txhdr = queuebuf_dataptr(i->packet);
    /* XXX warning */
    { /* TEST */
      uint16_t blaaa = 0xffff;
      memcpy(&txhdr->ack, &blaaa, 2);
    }
    if (i->bc) { /* XXX only send broadcast to prober */
      rimeaddr_copy(&txhdr->receiver, &rxhdr->sender);
    }
    NETSTACK_RADIO.prepare(queuebuf_dataptr(i->packet), queuebuf_datalen(i->packet));
    if (i->bc) { /* XXX only send broadcast to prober */
      rimeaddr_copy(&txhdr->receiver, &rimeaddr_null);
    }
    COOJA_DEBUG("data packet tx (immediate)");
    NETSTACK_RADIO.transmit(0); /* send vote packet */
    debug_preloaded_type = TYPE_NULL;
    busywait_until_sfd_true(); /* wait for transmission to start */
    busywait_until_sfd_false(); /* wait for transmission to finish */
    i->numtx = i->numtx + 1;
    //progress_14++;
    cc2420_flushrx(-1); /* potentially corrupted FIFO from vote phase */
    preload_vote(); /* new round - new random */
    rimeaddr_copy(&competition_neighbor, &rxhdr->sender);
    process_poll(&competition_timout_process);
    return 1;
  }

  return 0;
}
/*---------------------------------------------------------------------------*/
static void
init(void)
{
  memb_init(&queued_packets_memb);
  list_init(queued_packets_list);
  list_init(callback_packets_list);
  list_init(pending_packets_list);
  list_init(incoming_packets_list);

  rimeaddr_copy(&last_data_source, &rimeaddr_null);
  last_data_seq = 0;
  strawman_is_on = 1;

  restart_dutycycle(random_rand() % PROBE_INTERVAL);
  cc2420_set_peek_handler(cit_interrupt_handler, sizeof(struct strawman_hdr));

  ringbuf_init(&buf_competitions, buf_competitions_data, (uint8_t) 0xff&sizeof(buf_competitions_data));
  ringbuf_init(&buf_signals, buf_signals_data, (uint8_t) 0xff&sizeof(buf_signals_data));
  ringbuf_init(&buf_wins, buf_wins_data, (uint8_t) 0xff&sizeof(buf_wins_data));
  ringbuf_init(&buf_data, buf_data_data, (uint8_t) 0xff&sizeof(buf_data_data));
#if REQ_COMPETE_NEXT_BC
  ringbuf_init(&buf_latency, buf_data_latency, (uint8_t) 0xff&sizeof(buf_data_latency));
#endif

  process_start(&competition_timout_process, NULL);

  cc2420_set_channel(PROBE_CHANNEL);
}
/*---------------------------------------------------------------------------*/
void
strawman_set_testmode(int mode, int active)
{
  if (mode == STRAWMAN_PRINT_REQUESTS) {
    testmode_print_requests = active;
  } else if (mode == STRAWMAN_ALWAYS_REQUEST) {
    testmode_always_request = active;
  } else if (mode == STRAWMAN_PRINT_REQUEST_RSSI) {
    testmode_print_request_rssi = active;
  } else if (mode == STRAWMAN_STOP_ALL_TIMERS) {
    ctimer_stop(&timer);
  } else if (mode == STRAWMAN_ALWAYS_DATA) {
    testmode_always_request = active;
    testmode_always_data = active;
    testmode_no_probes = active;
  } else if (mode == STRAWMAN_DISCARD_DATA) {
    testmode_discard_data = active;
  } else if (mode == STRAWMAN_DONT_COMPETE) {
    testmode_dont_compete = active;
  } else if (mode == STRAWMAN_NO_CTS) {
    testmode_no_cts = active;
  } else if (mode == STRAWMAN_LIMIT_BC_TX) {
    testmode_limit_bc_tx = active;
  } else if (mode == STRAWMAN_DONT_PROBE) {
    testmode_no_probes = active;
  } else if (mode == STRAWMAN_NO_LOGS) {
    testmode_no_logs = active;
  } else if (mode == STRAWMAN_RADIO_ON) {
    testmode_radio_on = active;
    NETSTACK_RADIO.on();
  } else if (mode == STRAWMAN_INSTANT_BROADCASTS) {
    testmode_instant_broadcasts = active;
  } else if (mode == STRAWMAN_RIMAC) {
    testmode_rimac = active;
  } else {
    printf("bad testmode: %d\n", mode);
  }
}
/*---------------------------------------------------------------------------*/
const struct rdc_driver strawman_driver = {
  "StrawMAN",
  init,
  send_packet,
  packet_input,
  on,
  off,
  channel_check_interval,
};
/*---------------------------------------------------------------------------*/
