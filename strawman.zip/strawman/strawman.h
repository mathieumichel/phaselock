#ifndef __STRAWMAN_H__
#define __STRAWMAN_H__

#include "net/mac/rdc.h"
#include "dev/radio.h"

extern const struct rdc_driver strawman_driver;

/* Debugging variables */
extern int progress_1;
extern int progress_2;
extern int progress_3;
extern int progress_4;
extern int progress_5;
extern int progress_6;
extern int progress_7;
extern int progress_8;
extern int progress_9;
extern int progress_10;
extern int progress_11;
extern int progress_12;
extern int progress_14;
extern int progress_15;
extern int progress_16;

extern int strawman_got_synch;

extern struct ringbuf buf_competitions;
extern struct ringbuf buf_signals;
extern struct ringbuf buf_wins;
extern struct ringbuf buf_data;
extern struct ringbuf buf_latency;

/* Test modes */
#define STRAWMAN_ALWAYS_REQUEST 1 /* always send requests, even without data */
#define STRAWMAN_PRINT_REQUESTS 2 /* print request estimation (bytes) */
#define STRAWMAN_PRINT_REQUEST_RSSI 3
#define STRAWMAN_STOP_ALL_TIMERS 4
#define STRAWMAN_ALWAYS_DATA 5
#define STRAWMAN_DISCARD_DATA 6
#define STRAWMAN_DONT_COMPETE 7
#define STRAWMAN_NO_CTS 8
#define STRAWMAN_LIMIT_BC_TX 9
#define STRAWMAN_DONT_PROBE 10
#define STRAWMAN_NO_LOGS 11
#define STRAWMAN_RADIO_ON 12
#define STRAWMAN_INSTANT_BROADCASTS 13
#define STRAWMAN_RIMAC 14

void strawman_set_testmode(int mode, int active);

#endif /* __STRAWMAN_H__ */
